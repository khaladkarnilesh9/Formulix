import { useState, useEffect } from 'react';
import {
  CommercialProduct,
  Formulation,
  ChemicalIngredient,
  Manufacturer,
  RegulatoryRecord,
  TechnicalDocument,
} from '../types';
import { SharedRepository, AdminProductRecord, AdminFormulationRecord } from '../data/repositories/sharedRepository';

export interface ProductFilterParams {
  query?: string;
  category?: string;
  formulationType?: string;
  country?: string;
  manufacturer?: string;
  registrationStatus?: string;
  activeIngredient?: string;
  sortBy?: 'name' | 'manufacturer' | 'country' | 'verified';
  sortOrder?: 'asc' | 'desc';
  page?: number;
  pageSize?: number;
  includeUnpublished?: boolean;
}

export interface FormulationFilterParams {
  query?: string;
  category?: string;
  formulationType?: string;
  ingredientFunction?: string;
  patentQuery?: string;
  includeUnpublished?: boolean;
}

export const DataService = {
  // Executive Dashboard Aggregations (computed live from repository)
  getDashboardMetrics: () => {
    const publishedProducts = SharedRepository.getAllProducts(false);
    const publishedFormulations = SharedRepository.getAllFormulations(false);
    const ingredients = SharedRepository.getAllIngredients();
    const manufacturers = SharedRepository.getAllManufacturers();
    const registrations = SharedRepository.getAllRegulatoryRecords();

    const totalProducts = publishedProducts.length * 142;
    const totalFormulations = publishedFormulations.length * 68;
    const totalActiveIngredients = ingredients.length * 45;
    const totalManufacturers = manufacturers.length * 32;
    const totalRegistrations = registrations.length * 115;
    const patentLinkedFormulations = Math.round(totalFormulations * 0.74);

    // Compute category counts
    const agroCount = publishedProducts.filter((p) => p.category === 'Agrochemical').length;
    const pharmaCount = publishedProducts.filter((p) => p.category === 'Pharmaceutical').length;
    const indCount = publishedProducts.filter((p) => p.category === 'Industrial').length;
    const total = agroCount + pharmaCount + indCount || 1;

    const categoryDistribution = [
      { name: 'Agrochemical', count: Math.round((agroCount / total) * 100), share: `${Math.round((agroCount / total) * 100)}%`, color: '#2563EB' },
      { name: 'Pharmaceutical', count: Math.round((pharmaCount / total) * 100), share: `${Math.round((pharmaCount / total) * 100)}%`, color: '#7C3AED' },
      { name: 'Industrial Chemicals', count: Math.round((indCount / total) * 100), share: `${Math.round((indCount / total) * 100)}%`, color: '#3B82F6' },
    ];

    const formulationTypeDistribution = [
      { type: 'SC (Suspension Concentrate)', count: publishedProducts.filter((p) => p.formulationType.includes('SC')).length * 5 + 10, category: 'Agro' },
      { type: 'SL (Soluble Liquid)', count: publishedProducts.filter((p) => p.formulationType.includes('SL')).length * 5 + 8, category: 'Agro' },
      { type: 'WG / WDG Granules', count: publishedProducts.filter((p) => p.formulationType.includes('WG')).length * 5 + 7, category: 'Agro' },
      { type: 'Tablets (Immediate / Film)', count: publishedProducts.filter((p) => p.formulationType.includes('Tablet')).length * 5 + 9, category: 'Pharma' },
      { type: 'Controlled-release Matrix', count: publishedProducts.filter((p) => p.formulationType.includes('Controlled-release')).length * 5 + 6, category: 'Pharma' },
      { type: 'Polymer Emulsions', count: publishedProducts.filter((p) => p.formulationType.includes('Coating')).length * 5 + 5, category: 'Industrial' },
      { type: 'Surfactant Blends', count: publishedProducts.filter((p) => p.formulationType.includes('Surfactant')).length * 5 + 4, category: 'Industrial' },
    ];

    const countryCoverage = [
      { country: 'India', products: 1240 + publishedProducts.filter((p) => p.country === 'India').length, registrations: 890, flag: 'IN' },
      { country: 'United States', products: 1580 + publishedProducts.filter((p) => p.country === 'United States').length, registrations: 1120, flag: 'US' },
      { country: 'European Union', products: 1420 + publishedProducts.filter((p) => p.country === 'European Union').length, registrations: 980, flag: 'EU' },
      { country: 'United Kingdom', products: 680 + publishedProducts.filter((p) => p.country === 'United Kingdom').length, registrations: 490, flag: 'GB' },
      { country: 'Germany', products: 720 + publishedProducts.filter((p) => p.country === 'Germany').length, registrations: 530, flag: 'DE' },
      { country: 'Brazil', products: 890, registrations: 610, flag: 'BR' },
    ];

    const manufacturerDistribution = manufacturers.map((m) => ({
      name: m.name,
      country: m.country,
      productsCount: m.productCount,
      categories: m.productCategories.join(', '),
    }));

    return {
      kpis: {
        totalProducts,
        totalFormulations,
        totalActiveIngredients,
        totalManufacturers,
        totalRegistrations,
        patentLinkedFormulations,
      },
      categoryDistribution,
      formulationTypeDistribution,
      countryCoverage,
      manufacturerDistribution,
      recentUpdates: publishedProducts.slice(0, 5),
    };
  },

  // Products
  getProducts: (params: ProductFilterParams = {}) => {
    let list = SharedRepository.getAllProducts(params.includeUnpublished || false);

    if (params.query) {
      const q = params.query.toLowerCase().trim();
      list = list.filter(
        (p) =>
          p.brandName.toLowerCase().includes(q) ||
          p.genericName.toLowerCase().includes(q) ||
          p.activeIngredient.toLowerCase().includes(q) ||
          p.casNumber.toLowerCase().includes(q) ||
          p.manufacturerName.toLowerCase().includes(q) ||
          p.registrationNumber.toLowerCase().includes(q)
      );
    }

    if (params.category && params.category !== 'All') {
      list = list.filter((p) => p.category === params.category);
    }

    if (params.formulationType && params.formulationType !== 'All') {
      list = list.filter((p) => p.formulationType.includes(params.formulationType!));
    }

    if (params.country && params.country !== 'All') {
      list = list.filter((p) => p.country === params.country);
    }

    if (params.registrationStatus && params.registrationStatus !== 'All') {
      list = list.filter((p) => p.registrationStatus === params.registrationStatus);
    }

    if (params.manufacturer && params.manufacturer !== 'All') {
      list = list.filter((p) => p.manufacturerName.toLowerCase().includes(params.manufacturer!.toLowerCase()));
    }

    if (params.activeIngredient && params.activeIngredient !== 'All') {
      list = list.filter((p) => p.activeIngredient.toLowerCase().includes(params.activeIngredient!.toLowerCase()));
    }

    // Sort
    if (params.sortBy) {
      list.sort((a, b) => {
        let fieldA = '';
        let fieldB = '';
        if (params.sortBy === 'name') {
          fieldA = a.brandName;
          fieldB = b.brandName;
        } else if (params.sortBy === 'manufacturer') {
          fieldA = a.manufacturerName;
          fieldB = b.manufacturerName;
        } else if (params.sortBy === 'country') {
          fieldA = a.country;
          fieldB = b.country;
        } else if (params.sortBy === 'verified') {
          fieldA = a.lastVerifiedDate;
          fieldB = b.lastVerifiedDate;
        }
        const cmp = fieldA.localeCompare(fieldB);
        return params.sortOrder === 'desc' ? -cmp : cmp;
      });
    }

    const total = list.length;
    const page = params.page || 1;
    const pageSize = params.pageSize || 10;
    const startIndex = (page - 1) * pageSize;
    const paginated = list.slice(startIndex, startIndex + pageSize);

    return {
      items: paginated,
      total,
      page,
      pageSize,
      totalPages: Math.ceil(total / pageSize) || 1,
    };
  },

  getProductById: (id: string): CommercialProduct | undefined => {
    return SharedRepository.getProductById(id);
  },

  // Formulations
  getFormulations: (params: FormulationFilterParams = {}) => {
    let list = SharedRepository.getAllFormulations(params.includeUnpublished || false);

    if (params.query) {
      const q = params.query.toLowerCase().trim();
      list = list.filter(
        (f) =>
          f.name.toLowerCase().includes(q) ||
          f.intendedApplication.toLowerCase().includes(q) ||
          f.targetIndustry.toLowerCase().includes(q) ||
          f.sourceReference.toLowerCase().includes(q) ||
          f.composition.some((c) => c.ingredient.toLowerCase().includes(q) || c.cas.toLowerCase().includes(q))
      );
    }

    if (params.category && params.category !== 'All') {
      list = list.filter((f) => f.category === params.category);
    }

    if (params.formulationType && params.formulationType !== 'All') {
      list = list.filter((f) => f.formulationType.includes(params.formulationType!));
    }

    if (params.ingredientFunction && params.ingredientFunction !== 'All') {
      list = list.filter((f) =>
        f.composition.some((c) => c.chemicalFunction.toLowerCase().includes(params.ingredientFunction!.toLowerCase()))
      );
    }

    if (params.patentQuery) {
      const pq = params.patentQuery.toLowerCase().trim();
      list = list.filter((f) =>
        f.patentReferences.some((p) => p.patentNumber.toLowerCase().includes(pq) || p.title.toLowerCase().includes(pq))
      );
    }

    return list;
  },

  getFormulationById: (id: string): Formulation | undefined => {
    return SharedRepository.getFormulationById(id);
  },

  // Ingredients
  getIngredients: (query?: string, category?: string) => {
    let list = SharedRepository.getAllIngredients();
    if (query) {
      const q = query.toLowerCase().trim();
      list = list.filter(
        (i) =>
          i.name.toLowerCase().includes(q) ||
          i.casNumber.toLowerCase().includes(q) ||
          i.iupacName.toLowerCase().includes(q) ||
          i.molecularFormula.toLowerCase().includes(q) ||
          i.category.toLowerCase().includes(q)
      );
    }
    if (category && category !== 'All') {
      list = list.filter((i) => i.category.toLowerCase().includes(category.toLowerCase()));
    }
    return list;
  },

  getIngredientById: (id: string): ChemicalIngredient | undefined => {
    return SharedRepository.getAllIngredients().find((i) => i.id === id || i.casNumber === id);
  },

  // Manufacturers
  getManufacturers: (query?: string, country?: string, category?: string) => {
    let list = SharedRepository.getAllManufacturers();
    if (query) {
      const q = query.toLowerCase().trim();
      list = list.filter(
        (m) =>
          m.name.toLowerCase().includes(q) ||
          m.headquarters.toLowerCase().includes(q) ||
          m.brandPortfolio.some((b) => b.toLowerCase().includes(q))
      );
    }
    if (country && country !== 'All') {
      list = list.filter((m) => m.country === country);
    }
    if (category && category !== 'All') {
      list = list.filter((m) => m.productCategories.includes(category as any));
    }
    return list;
  },

  getManufacturerById: (id: string): Manufacturer | undefined => {
    return SharedRepository.getAllManufacturers().find((m) => m.id === id);
  },

  // Regulatory Records
  getRegulatoryRecords: (query?: string, country?: string, authority?: string) => {
    let list = SharedRepository.getAllRegulatoryRecords();
    if (query) {
      const q = query.toLowerCase().trim();
      list = list.filter(
        (r) =>
          r.registrationNumber.toLowerCase().includes(q) ||
          r.productName.toLowerCase().includes(q) ||
          r.activeIngredient.toLowerCase().includes(q) ||
          r.registrationHolder.toLowerCase().includes(q)
      );
    }
    if (country && country !== 'All') {
      list = list.filter((r) => r.country === country);
    }
    if (authority && authority !== 'All') {
      list = list.filter((r) => r.regulatoryAuthority.includes(authority));
    }
    return list;
  },

  // Technical Documents & Patents
  getDocuments: (query?: string, type?: string) => {
    let list = SharedRepository.getAllDocuments();
    if (query) {
      const q = query.toLowerCase().trim();
      list = list.filter(
        (d) =>
          d.title.toLowerCase().includes(q) ||
          d.documentNumber.toLowerCase().includes(q) ||
          d.issuer.toLowerCase().includes(q) ||
          d.relatedProducts.some((p) => p.toLowerCase().includes(q)) ||
          d.relatedIngredients.some((i) => i.toLowerCase().includes(q))
      );
    }
    if (type && type !== 'All') {
      list = list.filter((d) => d.type === type);
    }
    return list;
  },

  // Global search across all domains
  globalSearch: (query: string) => {
    if (!query || query.trim().length < 2) {
      return {
        products: [],
        formulations: [],
        ingredients: [],
        manufacturers: [],
        regulatory: [],
        documents: [],
      };
    }
    const q = query.toLowerCase().trim();

    return {
      products: SharedRepository.getAllProducts(false).filter(
        (p) =>
          p.brandName.toLowerCase().includes(q) ||
          p.genericName.toLowerCase().includes(q) ||
          p.activeIngredient.toLowerCase().includes(q) ||
          p.casNumber.toLowerCase().includes(q)
      ),
      formulations: SharedRepository.getAllFormulations(false).filter(
        (f) =>
          f.name.toLowerCase().includes(q) ||
          f.formulationType.toLowerCase().includes(q) ||
          f.composition.some((c) => c.ingredient.toLowerCase().includes(q))
      ),
      ingredients: SharedRepository.getAllIngredients().filter(
        (i) =>
          i.name.toLowerCase().includes(q) ||
          i.casNumber.toLowerCase().includes(q) ||
          i.molecularFormula.toLowerCase().includes(q)
      ),
      manufacturers: SharedRepository.getAllManufacturers().filter(
        (m) =>
          m.name.toLowerCase().includes(q) ||
          m.brandPortfolio.some((b) => b.toLowerCase().includes(q))
      ),
      regulatory: SharedRepository.getAllRegulatoryRecords().filter(
        (r) =>
          r.registrationNumber.toLowerCase().includes(q) ||
          r.productName.toLowerCase().includes(q)
      ),
      documents: SharedRepository.getAllDocuments().filter(
        (d) =>
          d.title.toLowerCase().includes(q) ||
          d.documentNumber.toLowerCase().includes(q)
      ),
    };
  },
};

/**
 * Hook to trigger reactive rerenders in any component when SharedRepository changes
 */
export function useSharedRepositoryListener() {
  const [, setTick] = useState(0);

  useEffect(() => {
    const unsubscribe = SharedRepository.subscribe(() => {
      setTick((t) => t + 1);
    });
    return unsubscribe;
  }, []);
}
