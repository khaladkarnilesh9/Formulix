/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import { Sidebar, NavItemKey } from './components/layout/Sidebar';
import { Header } from './components/layout/Header';
import { GlobalSearchModal } from './components/layout/GlobalSearchModal';
import { ToastProvider } from './components/common/Toast';
import { DataService } from './services/dataService';
import { DashboardView } from './features/dashboard/DashboardView';
import { ProductSearchView } from './features/products/ProductSearchView';
import { ProductDetailView } from './features/products/ProductDetailView';
import { FormulationIntelligenceView } from './features/formulations/FormulationIntelligenceView';
import { IngredientExplorerView } from './features/ingredients/IngredientExplorerView';
import { ProductComparisonView } from './features/comparison/ProductComparisonView';
import { ManufacturerDirectoryView } from './features/manufacturers/ManufacturerDirectoryView';
import { BrandIntelligenceView } from './features/manufacturers/BrandIntelligenceView';
import { RegulatoryIntelligenceView } from './features/regulatory/RegulatoryIntelligenceView';
import { PatentDocumentsView } from './features/documents/PatentDocumentsView';
import { WorkspaceView } from './features/workspace/WorkspaceView';
import { SettingsView } from './features/settings/SettingsView';

// Admin Portal Components
import { AdminLayout } from './features/admin/layout/AdminLayout';
import { AdminTabKey } from './features/admin/layout/AdminSidebar';
import { AdminDashboardView } from './features/admin/dashboard/AdminDashboardView';
import { AdminProductListView } from './features/admin/products/AdminProductListView';
import { AdminProductFormWizard } from './features/admin/products/AdminProductFormWizard';
import { AdminFormulationsView } from './features/admin/formulations/AdminFormulationsView';
import { AdminIngredientsView } from './features/admin/ingredients/AdminIngredientsView';
import { AdminManufacturersView } from './features/admin/manufacturers/AdminManufacturersView';
import { AdminBrandsView } from './features/admin/brands/AdminBrandsView';
import { AdminRegistrationsView } from './features/admin/regulatory/AdminRegistrationsView';
import { AdminDocumentsView } from './features/admin/documents/AdminDocumentsView';
import { AdminBulkImportExportView } from './features/admin/imports/AdminBulkImportExportView';
import { AdminIndianAgroAcquisitionView } from './features/admin/imports/AdminIndianAgroAcquisitionView';
import { AdminReviewQueueView } from './features/admin/review/AdminReviewQueueView';
import { AdminDataQualityView } from './features/admin/quality/AdminDataQualityView';
import { AdminMasterDataView } from './features/admin/masterdata/AdminMasterDataView';
import { AdminAuditLogsView } from './features/admin/audit/AdminAuditLogsView';
import { AdminFieldAuditMatrixView } from './features/admin/matrix/AdminFieldAuditMatrixView';
import { AdminE2ETestRunnerView } from './features/admin/testing/AdminE2ETestRunnerView';
import { AdminSettingsView as AdminSystemSettingsView } from './features/admin/settings/AdminSettingsView';
import { AdminProductRecord } from './data/repositories/sharedRepository';

export default function App() {
  // Top-level portal switch: 'user' | 'admin'
  const [portal, setPortal] = useState<'user' | 'admin'>('user');

  // User Portal Navigation State
  const [currentTab, setCurrentTab] = useState<NavItemKey>('dashboard');
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const [mobileSidebarOpen, setMobileSidebarOpen] = useState(false);
  const [isSearchOpen, setIsSearchOpen] = useState(false);

  // Admin Portal Navigation State
  const [adminTab, setAdminTab] = useState<AdminTabKey>('admin-dashboard');
  const [operatorRole, setOperatorRole] = useState('Principal Architect');
  const [editingProduct, setEditingProduct] = useState<AdminProductRecord | null>(null);

  // Deep-dive selection states
  const [selectedProductId, setSelectedProductId] = useState<string>('prod-1');
  const [selectedFormulationId, setSelectedFormulationId] = useState<string>('form-1');
  const [selectedIngredientCas, setSelectedIngredientCas] = useState<string>('ing-1');
  const [selectedMfgId, setSelectedMfgId] = useState<string>('mfg-1');
  const [selectedDocId, setSelectedDocId] = useState<string | undefined>(undefined);

  // Global Keyboard Shortcut: ⌘K or Ctrl+K to open Search
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === 'k') {
        e.preventDefault();
        setIsSearchOpen((prev) => !prev);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, []);

  const handleNavigate = (module: string, itemId?: string) => {
    switch (module) {
      case 'dashboard':
        setCurrentTab('dashboard');
        break;
      case 'products':
      case 'product-search':
        if (itemId) {
          setSelectedProductId(itemId);
          setCurrentTab('product-detail');
        } else {
          setCurrentTab('product-search');
        }
        break;
      case 'product-detail':
        if (itemId) setSelectedProductId(itemId);
        setCurrentTab('product-detail');
        break;
      case 'formulations':
      case 'formulation-explorer':
        if (itemId) setSelectedFormulationId(itemId);
        setCurrentTab('formulation-explorer');
        break;
      case 'ingredients':
      case 'ingredient-explorer':
        if (itemId) setSelectedIngredientCas(itemId);
        setCurrentTab('ingredient-explorer');
        break;
      case 'product-comparison':
        setCurrentTab('product-comparison');
        break;
      case 'manufacturers':
      case 'manufacturer-directory':
        if (itemId) setSelectedMfgId(itemId);
        setCurrentTab('manufacturer-directory');
        break;
      case 'brand-intelligence':
        setCurrentTab('brand-intelligence');
        break;
      case 'regulatory':
      case 'regulatory-intelligence':
        setCurrentTab('regulatory-intelligence');
        break;
      case 'documents':
      case 'patent-intelligence':
      case 'technical-documents':
        if (itemId) setSelectedDocId(itemId);
        setCurrentTab('patent-intelligence');
        break;
      case 'saved-items':
        setCurrentTab('saved-items');
        break;
      case 'research-workspace':
        setCurrentTab('research-workspace');
        break;
      case 'settings':
        setCurrentTab('settings');
        break;
      default:
        setCurrentTab('dashboard');
    }
    setMobileSidebarOpen(false);
  };

  const handleSelectProduct = (id: string) => {
    setSelectedProductId(id);
    setCurrentTab('product-detail');
  };

  const handleSelectFormulation = (id: string) => {
    setSelectedFormulationId(id);
    setCurrentTab('formulation-explorer');
  };

  const handleSelectIngredient = (casOrId: string) => {
    setSelectedIngredientCas(casOrId);
    setCurrentTab('ingredient-explorer');
  };

  const handleSelectManufacturer = (id: string) => {
    setSelectedMfgId(id);
    setCurrentTab('manufacturer-directory');
  };

  const handleOpenDocument = (docId: string) => {
    setSelectedDocId(docId);
    setCurrentTab('patent-intelligence');
  };

  return (
    <ToastProvider>
      {portal === 'admin' ? (
        <AdminLayout
          currentTab={adminTab}
          onTabChange={(tab) => {
            if (tab === 'admin-products-new') {
              setEditingProduct(null);
            }
            setAdminTab(tab);
          }}
          onExitToUserPortal={() => setPortal('user')}
          operatorRole={operatorRole}
          onChangeOperatorRole={setOperatorRole}
        >
          {adminTab === 'admin-dashboard' && (
            <AdminDashboardView onNavigate={(tab) => setAdminTab(tab)} />
          )}

          {adminTab === 'admin-indian-agro' && (
            <AdminIndianAgroAcquisitionView />
          )}

          {adminTab === 'admin-products' && (
            <AdminProductListView
              onCreateNewProduct={() => {
                setEditingProduct(null);
                setAdminTab('admin-products-new');
              }}
              onEditProduct={(p) => {
                setEditingProduct(p);
                setAdminTab('admin-products-new');
              }}
              onPreviewInUserPortal={(productId) => {
                setSelectedProductId(productId);
                setCurrentTab('product-detail');
                setPortal('user');
              }}
            />
          )}

          {adminTab === 'admin-products-new' && (
            <AdminProductFormWizard
              initialProduct={editingProduct}
              onSaveSuccess={(p) => {
                setEditingProduct(null);
                setAdminTab('admin-products');
              }}
              onCancel={() => {
                setEditingProduct(null);
                setAdminTab('admin-products');
              }}
              operatorRole={operatorRole}
            />
          )}

          {adminTab === 'admin-formulations' && (
            <AdminFormulationsView
              onPreviewInUserPortal={(formId) => {
                setSelectedFormulationId(formId);
                setCurrentTab('formulation-explorer');
                setPortal('user');
              }}
            />
          )}

          {adminTab === 'admin-ingredients' && (
            <AdminIngredientsView
              onPreviewInUserPortal={(casOrId) => {
                setSelectedIngredientCas(casOrId);
                setCurrentTab('ingredient-explorer');
                setPortal('user');
              }}
            />
          )}

          {adminTab === 'admin-manufacturers' && (
            <AdminManufacturersView
              onPreviewInUserPortal={(mfgId) => {
                setSelectedMfgId(mfgId);
                setCurrentTab('manufacturer-directory');
                setPortal('user');
              }}
            />
          )}

          {adminTab === 'admin-brands' && (
            <AdminBrandsView
              onSelectProduct={(productId) => {
                setSelectedProductId(productId);
                setCurrentTab('product-detail');
                setPortal('user');
              }}
            />
          )}

          {adminTab === 'admin-registrations' && <AdminRegistrationsView />}

          {(adminTab === 'admin-patents' || adminTab === 'admin-documents') && (
            <AdminDocumentsView />
          )}

          {adminTab === 'admin-imports' && <AdminBulkImportExportView />}

          {adminTab === 'admin-review' && (
            <AdminReviewQueueView
              onInspectProduct={(p) => {
                setEditingProduct(p);
                setAdminTab('admin-products-new');
              }}
            />
          )}

          {adminTab === 'admin-data-quality' && <AdminDataQualityView />}

          {adminTab === 'admin-master-data' && <AdminMasterDataView />}

          {adminTab === 'admin-audit-logs' && <AdminAuditLogsView />}

          {adminTab === 'admin-field-audit' && <AdminFieldAuditMatrixView />}

          {adminTab === 'admin-e2e-tests' && <AdminE2ETestRunnerView />}

          {adminTab === 'admin-settings' && (
            <AdminSystemSettingsView
              operatorRole={operatorRole}
              onChangeOperatorRole={setOperatorRole}
            />
          )}
        </AdminLayout>
      ) : (
        <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex transition-colors duration-200">
          {/* Persistent Desktop Sidebar */}
          <div className="hidden lg:block">
            <Sidebar
              currentTab={currentTab}
              onTabChange={(tab) => {
                setCurrentTab(tab);
              }}
              collapsed={sidebarCollapsed}
              onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)}
              onSwitchToAdmin={() => setPortal('admin')}
            />
          </div>

          {/* Mobile Drawer Sidebar */}
          {mobileSidebarOpen && (
            <div className="fixed inset-0 z-50 lg:hidden">
              <div
                className="fixed inset-0 bg-slate-950/60 backdrop-blur-xs"
                onClick={() => setMobileSidebarOpen(false)}
              />
              <div className="fixed inset-y-0 left-0 w-64 bg-white dark:bg-slate-950 z-50">
                <Sidebar
                  currentTab={currentTab}
                  onTabChange={(tab) => {
                    setCurrentTab(tab);
                    setMobileSidebarOpen(false);
                  }}
                  collapsed={false}
                  onToggleCollapse={() => setMobileSidebarOpen(false)}
                  onSwitchToAdmin={() => {
                    setPortal('admin');
                    setMobileSidebarOpen(false);
                  }}
                />
              </div>
            </div>
          )}

          {/* Main Workspace Frame */}
          <div
            className={`flex-1 flex flex-col min-w-0 transition-all duration-300 ${
              sidebarCollapsed ? 'lg:pl-18' : 'lg:pl-64'
            }`}
          >
            {/* Header */}
            <Header
              currentTab={currentTab}
              onOpenSearch={() => setIsSearchOpen(true)}
              onNavigate={(tab) => setCurrentTab(tab)}
              onToggleSidebarMobile={() => setMobileSidebarOpen(true)}
              onSwitchToAdmin={() => setPortal('admin')}
            />

            {/* Body Content Area */}
            <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
              {currentTab === 'dashboard' && (
                <DashboardView
                  onNavigate={handleNavigate}
                  onOpenSearch={() => setIsSearchOpen(true)}
                />
              )}

              {currentTab === 'product-search' && (
                <ProductSearchView
                  onSelectProduct={handleSelectProduct}
                  onNavigateComparison={() => setCurrentTab('product-comparison')}
                />
              )}

              {currentTab === 'product-detail' && (
                <ProductDetailView
                  productId={selectedProductId}
                  onBack={() => setCurrentTab('product-search')}
                  onNavigateToFormulation={handleSelectFormulation}
                  onNavigateToIngredient={handleSelectIngredient}
                  onNavigateToManufacturer={handleSelectManufacturer}
                  onOpenDocument={handleOpenDocument}
                />
              )}

              {currentTab === 'formulation-explorer' && (
                <FormulationIntelligenceView
                  initialFormulationId={selectedFormulationId}
                  onSelectProduct={handleSelectProduct}
                  onSelectIngredient={handleSelectIngredient}
                />
              )}

              {currentTab === 'ingredient-explorer' && (
                <IngredientExplorerView
                  initialCasOrId={selectedIngredientCas}
                  onSelectProduct={handleSelectProduct}
                  onSelectManufacturer={handleSelectManufacturer}
                />
              )}

              {currentTab === 'product-comparison' && (
                <ProductComparisonView
                  onSelectProduct={handleSelectProduct}
                  onNavigateToSearch={() => setCurrentTab('product-search')}
                />
              )}

              {currentTab === 'manufacturer-directory' && (
                <ManufacturerDirectoryView
                  initialManufacturerId={selectedMfgId}
                  onSelectProduct={handleSelectProduct}
                />
              )}

              {currentTab === 'brand-intelligence' && (
                <BrandIntelligenceView
                  onSelectProduct={handleSelectProduct}
                  onSelectManufacturer={handleSelectManufacturer}
                />
              )}

              {currentTab === 'regulatory-intelligence' && (
                <RegulatoryIntelligenceView
                  onSelectProduct={handleSelectProduct}
                />
              )}

              {(currentTab === 'patent-intelligence' || currentTab === 'technical-documents') && (
                <PatentDocumentsView
                  onSelectProduct={(name) => {
                    const match = DataService.getProducts({ query: name }).items[0];
                    if (match) handleSelectProduct(match.id);
                    else setCurrentTab('product-search');
                  }}
                  onSelectIngredient={handleSelectIngredient}
                  selectedDocId={selectedDocId}
                />
              )}

              {currentTab === 'saved-items' && (
                <WorkspaceView
                  onSelectProduct={handleSelectProduct}
                  onSelectFormulation={handleSelectFormulation}
                  onSelectManufacturer={handleSelectManufacturer}
                  initialTab="saved"
                />
              )}

              {currentTab === 'research-workspace' && (
                <WorkspaceView
                  onSelectProduct={handleSelectProduct}
                  onSelectFormulation={handleSelectFormulation}
                  onSelectManufacturer={handleSelectManufacturer}
                  initialTab="notes"
                />
              )}

              {currentTab === 'settings' && <SettingsView />}
            </main>
          </div>

          {/* Global Search Dialog (⌘K) */}
          <GlobalSearchModal
            isOpen={isSearchOpen}
            onClose={() => setIsSearchOpen(false)}
            onNavigate={handleNavigate}
          />
        </div>
      )}
    </ToastProvider>
  );
}
