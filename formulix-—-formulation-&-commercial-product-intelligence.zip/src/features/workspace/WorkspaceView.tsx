import React, { useState } from 'react';
import { useWorkspaceStore } from '../../stores/workspaceStore';
import { DataService } from '../../services/dataService';
import { useToast } from '../../components/common/Toast';
import { EvidenceBadge, StatusIndicator } from '../../components/common/EvidenceBadge';
import {
  Bookmark,
  FlaskConical,
  Package,
  Building2,
  FileText,
  Clock,
  Plus,
  Trash2,
  Edit2,
  Save,
  Tag,
  ArrowRight,
  Download,
  Share2,
} from 'lucide-react';

interface WorkspaceViewProps {
  onSelectProduct: (productId: string) => void;
  onSelectFormulation: (formId: string) => void;
  onSelectManufacturer: (mfgId: string) => void;
  initialTab?: 'saved' | 'notes' | 'activity';
}

export const WorkspaceView: React.FC<WorkspaceViewProps> = ({
  onSelectProduct,
  onSelectFormulation,
  onSelectManufacturer,
  initialTab = 'saved',
}) => {
  const { toast } = useToast();
  const {
    savedProductIds,
    toggleSavedProduct,
    savedFormulationIds,
    toggleSavedFormulation,
    bookmarkedManufacturerIds,
    toggleBookmarkedManufacturer,
    researchNotes,
    addNote,
    updateNote,
    deleteNote,
    recentActivities,
  } = useWorkspaceStore();

  const [activeTab, setActiveTab] = useState<'saved' | 'notes' | 'activity'>(initialTab);

  // Note editor states
  const [isCreatingNote, setIsCreatingNote] = useState(false);
  const [editingNoteId, setEditingNoteId] = useState<string | null>(null);
  const [noteTitle, setNoteTitle] = useState('');
  const [noteContent, setNoteContent] = useState('');
  const [noteCategory, setNoteCategory] = useState('Formulation R&D');
  const [noteTags, setNoteTags] = useState('Agrochemical, Stability');

  const savedProducts = savedProductIds
    .map((id) => DataService.getProductById(id))
    .filter((p) => p !== undefined);

  const savedFormulations = savedFormulationIds
    .map((id) => DataService.getFormulationById(id))
    .filter((f) => f !== undefined);

  const bookmarkedManufacturers = bookmarkedManufacturerIds
    .map((id) => DataService.getManufacturerById(id))
    .filter((m) => m !== undefined);

  const handleSaveNewNote = () => {
    if (!noteTitle.trim()) {
      toast('Please enter a note title', 'warning');
      return;
    }
    const tagsArray = noteTags.split(',').map((t) => t.trim()).filter(Boolean);
    addNote(noteTitle, noteContent, noteCategory, tagsArray);
    setIsCreatingNote(false);
    setNoteTitle('');
    setNoteContent('');
    toast('Research note saved to workspace');
  };

  const handleUpdateExistingNote = () => {
    if (!editingNoteId || !noteTitle.trim()) return;
    const tagsArray = noteTags.split(',').map((t) => t.trim()).filter(Boolean);
    updateNote(editingNoteId, noteTitle, noteContent, tagsArray);
    setEditingNoteId(null);
    setNoteTitle('');
    setNoteContent('');
    toast('Research note updated');
  };

  const startEditNote = (note: any) => {
    setEditingNoteId(note.id);
    setNoteTitle(note.title);
    setNoteContent(note.content);
    setNoteCategory(note.category);
    setNoteTags(note.tags.join(', '));
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Top Banner */}
      <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-purple-600 dark:text-purple-400">
            <span>LOCAL REPOSITORIES & SCIENTIFIC FIELD NOTES</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">
            Formulation Research Workspace
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Bookmarked chemical formulations, custom laboratory notes, and multi-session audit activity.
          </p>
        </div>

        {/* Workspace Tab Switcher */}
        <div className="flex items-center gap-1 p-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-xs font-medium">
          <button
            onClick={() => setActiveTab('saved')}
            className={`px-3 py-1.5 rounded-md transition-colors ${
              activeTab === 'saved'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Saved Items ({savedProducts.length + savedFormulations.length})
          </button>
          <button
            onClick={() => setActiveTab('notes')}
            className={`px-3 py-1.5 rounded-md transition-colors ${
              activeTab === 'notes'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Research Notes ({researchNotes.length})
          </button>
          <button
            onClick={() => setActiveTab('activity')}
            className={`px-3 py-1.5 rounded-md transition-colors ${
              activeTab === 'activity'
                ? 'bg-white dark:bg-slate-900 text-slate-900 dark:text-white shadow-2xs'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900'
            }`}
          >
            Audit History ({recentActivities.length})
          </button>
        </div>
      </div>

      {/* TAB 1: SAVED ITEMS */}
      {activeTab === 'saved' && (
        <div className="space-y-6">
          {/* Saved Products */}
          <div className="space-y-3">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2">
              <Package className="w-4 h-4 text-blue-500" />
              <span>Saved Commercial Products ({savedProducts.length})</span>
            </h3>

            {savedProducts.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-400 border border-slate-200 dark:border-slate-800 rounded-lg">
                No commercial products saved yet. Bookmark products from the catalog search view.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
                {savedProducts.map((p) => (
                  <div
                    key={p.id}
                    className="p-3.5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs space-y-2 flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between text-xs text-slate-500 pb-1.5 border-b border-slate-100 dark:border-slate-800">
                        <span className="font-mono text-[10px] text-blue-600 dark:text-blue-400">{p.category}</span>
                        <button
                          onClick={() => {
                            toggleSavedProduct(p.id, p.brandName);
                            toast(`Removed "${p.brandName}" from saved`);
                          }}
                          className="text-slate-400 hover:text-rose-500"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="pt-2">
                        <div
                          onClick={() => onSelectProduct(p.id)}
                          className="font-bold text-sm text-slate-900 dark:text-white hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer"
                        >
                          {p.brandName}
                        </div>
                        <div className="text-xs text-slate-500 font-medium">{p.genericName}</div>
                        <div className="text-[11px] font-mono text-slate-400 mt-1">
                          {p.activeIngredient} · {p.strength}
                        </div>
                      </div>
                    </div>

                    <button
                      onClick={() => onSelectProduct(p.id)}
                      className="mt-2 text-xs font-medium text-blue-600 dark:text-blue-400 hover:underline flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800"
                    >
                      <span>View Specifications</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Saved Formulations */}
          <div className="space-y-3 pt-4 border-t border-slate-200 dark:border-slate-800">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2">
              <FlaskConical className="w-4 h-4 text-purple-500" />
              <span>Saved Formulation Recipes ({savedFormulations.length})</span>
            </h3>

            {savedFormulations.length === 0 ? (
              <div className="p-6 text-center text-xs text-slate-400 border border-slate-200 dark:border-slate-800 rounded-lg">
                No formulation recipes saved yet. Save recipes from the Formulation Explorer.
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {savedFormulations.map((f) => (
                  <div
                    key={f.id}
                    className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs space-y-2 flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between text-xs text-slate-500 pb-1.5 border-b border-slate-100 dark:border-slate-800">
                        <span className="font-mono text-[10px] text-purple-600 dark:text-purple-400">{f.formulationType}</span>
                        <button
                          onClick={() => {
                            toggleSavedFormulation(f.id, f.name);
                            toast(`Removed "${f.name}" from saved recipes`);
                          }}
                          className="text-slate-400 hover:text-rose-500"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <div className="pt-2">
                        <div
                          onClick={() => onSelectFormulation(f.id)}
                          className="font-bold text-sm text-slate-900 dark:text-white hover:text-purple-600 dark:hover:text-purple-400 cursor-pointer"
                        >
                          {f.name}
                        </div>
                        <p className="text-xs text-slate-600 dark:text-slate-400 mt-1 line-clamp-2">
                          {f.intendedApplication}
                        </p>
                      </div>
                    </div>

                    <button
                      onClick={() => onSelectFormulation(f.id)}
                      className="mt-2 text-xs font-medium text-purple-600 dark:text-purple-400 hover:underline flex items-center justify-between pt-2 border-t border-slate-100 dark:border-slate-800"
                    >
                      <span>Open Full Manufacturing Flowsheet</span>
                      <ArrowRight className="w-3 h-3" />
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* TAB 2: RESEARCH NOTES */}
      {activeTab === 'notes' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
              Formulation Field Notes & Lab Observations
            </h3>

            {!isCreatingNote && !editingNoteId && (
              <button
                onClick={() => {
                  setIsCreatingNote(true);
                  setNoteTitle('');
                  setNoteContent('');
                }}
                className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-blue-600 hover:bg-blue-700 text-white transition-colors"
              >
                <Plus className="w-3.5 h-3.5" />
                <span>New Research Note</span>
              </button>
            )}
          </div>

          {/* New / Edit Note Form */}
          {(isCreatingNote || editingNoteId) && (
            <div className="p-4 rounded-xl border border-blue-200 dark:border-blue-900/60 bg-blue-50/30 dark:bg-blue-950/20 space-y-3">
              <div className="font-semibold text-xs text-blue-950 dark:text-blue-300">
                {editingNoteId ? 'Edit Research Note' : 'Draft New Research Note'}
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <input
                  type="text"
                  placeholder="Note Title (e.g. Chlorantraniliprole Wet Milling Study)"
                  value={noteTitle}
                  onChange={(e) => setNoteTitle(e.target.value)}
                  className="w-full p-2 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                />

                <select
                  value={noteCategory}
                  onChange={(e) => setNoteCategory(e.target.value)}
                  className="p-2 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-800 dark:text-slate-200"
                >
                  <option value="Formulation R&D">Formulation R&D</option>
                  <option value="Patent Intelligence">Patent Intelligence</option>
                  <option value="Green Chemistry">Green Chemistry</option>
                  <option value="Regulatory Compliance">Regulatory Compliance</option>
                </select>
              </div>

              <textarea
                rows={4}
                placeholder="Write your research observations, analytical findings, or formulation hypothesis..."
                value={noteContent}
                onChange={(e) => setNoteContent(e.target.value)}
                className="w-full p-2.5 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
              />

              <div className="flex items-center gap-2">
                <Tag className="w-3.5 h-3.5 text-slate-400" />
                <input
                  type="text"
                  placeholder="Comma separated tags (e.g., Rheology, SC, Zirconia Beads)"
                  value={noteTags}
                  onChange={(e) => setNoteTags(e.target.value)}
                  className="flex-1 p-2 text-xs rounded-lg border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-slate-900 dark:text-white"
                />
              </div>

              <div className="flex items-center justify-end gap-2 pt-2">
                <button
                  onClick={() => {
                    setIsCreatingNote(false);
                    setEditingNoteId(null);
                  }}
                  className="px-3 py-1.5 rounded-lg text-xs font-medium text-slate-600 dark:text-slate-300 hover:bg-slate-200/50"
                >
                  Cancel
                </button>
                <button
                  onClick={editingNoteId ? handleUpdateExistingNote : handleSaveNewNote}
                  className="px-4 py-1.5 rounded-lg text-xs font-medium bg-blue-600 text-white hover:bg-blue-700"
                >
                  {editingNoteId ? 'Update Note' : 'Save to Workspace'}
                </button>
              </div>
            </div>
          )}

          {/* Notes Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {researchNotes.map((note) => (
              <div
                key={note.id}
                className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs space-y-3 flex flex-col justify-between"
              >
                <div>
                  <div className="flex items-center justify-between text-xs text-slate-400 pb-2 border-b border-slate-100 dark:border-slate-800">
                    <span className="font-semibold text-blue-600 dark:text-blue-400">{note.category}</span>
                    <span className="font-mono text-[11px]">{note.updatedAt}</span>
                  </div>

                  <div className="pt-2">
                    <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                      {note.title}
                    </h4>
                    <p className="text-xs text-slate-600 dark:text-slate-400 mt-2 leading-relaxed whitespace-pre-wrap">
                      {note.content}
                    </p>
                  </div>

                  <div className="flex flex-wrap gap-1.5 mt-3">
                    {note.tags.map((t) => (
                      <span
                        key={t}
                        className="px-2 py-0.5 rounded text-[10px] bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 font-mono"
                      >
                        #{t}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="pt-2 border-t border-slate-100 dark:border-slate-800 flex items-center justify-end gap-2 text-xs">
                  <button
                    onClick={() => startEditNote(note)}
                    className="p-1 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                    title="Edit Note"
                  >
                    <Edit2 className="w-3.5 h-3.5" />
                  </button>
                  <button
                    onClick={() => {
                      deleteNote(note.id);
                      toast('Deleted note');
                    }}
                    className="p-1 text-slate-400 hover:text-rose-600"
                    title="Delete Note"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                  </button>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* TAB 3: AUDIT HISTORY TIMELINE */}
      {activeTab === 'activity' && (
        <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs space-y-4">
          <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white flex items-center gap-2">
              <Clock className="w-4 h-4 text-blue-500" />
              <span>Workspace Audit Trail & Session Navigation</span>
            </h3>
            <span className="text-xs font-mono text-slate-400">
              {recentActivities.length} Actions Logged
            </span>
          </div>

          <div className="space-y-3">
            {recentActivities.map((act) => (
              <div
                key={act.id}
                className="flex items-center justify-between p-3 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-slate-100 dark:border-slate-800/80 text-xs"
              >
                <div className="space-y-0.5">
                  <div className="font-semibold text-slate-900 dark:text-white">
                    {act.targetName}
                  </div>
                  <div className="text-slate-500 text-[11px]">
                    <span className="font-medium text-blue-600 dark:text-blue-400">{act.action}</span>
                    <span aria-hidden="true"> · </span>
                    <span className="font-mono text-slate-400">{act.targetType}</span>
                  </div>
                </div>

                <div className="font-mono text-[11px] text-slate-400">
                  {act.timestamp}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};
