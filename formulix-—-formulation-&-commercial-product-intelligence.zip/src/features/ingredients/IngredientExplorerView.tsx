import React, { useState } from 'react';
import { DataService } from '../../services/dataService';
import { ChemicalIngredient } from '../../types';
import { ChemicalStructureViewer } from '../../components/common/ChemicalStructureViewer';
import { useToast } from '../../components/common/Toast';
import {
  Atom,
  Search,
  Filter,
  Copy,
  Check,
  Package,
  Building2,
  AlertTriangle,
  RotateCcw,
  ExternalLink,
  ChevronRight,
  Info,
  Sparkles,
} from 'lucide-react';

interface IngredientExplorerViewProps {
  initialCasOrId?: string;
  onSelectProduct: (productId: string) => void;
  onSelectManufacturer: (mfgId: string) => void;
}

export const IngredientExplorerView: React.FC<IngredientExplorerViewProps> = ({
  initialCasOrId,
  onSelectProduct,
  onSelectManufacturer,
}) => {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activeIngredientId, setActiveIngredientId] = useState<string>(
    initialCasOrId || 'ing-1'
  );

  const ingredients = DataService.getIngredients(searchQuery, selectedCategory);
  const activeIngredient =
    DataService.getIngredientById(activeIngredientId) || ingredients[0];

  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const handleCopy = (text: string, label: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(label);
    toast(`Copied ${label} to clipboard`);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Top Banner */}
      <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-blue-600 dark:text-blue-400">
            <span>MOLECULAR CHEMICAL SUBSTANCE REGISTRY</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">
            Chemical Ingredient & API Explorer
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Verified CAS registry entities, canonical SMILES, InChIKeys, and associated commercial formulation linkages.
          </p>
        </div>

        {/* Category Filter */}
        <div className="flex items-center gap-1.5 flex-wrap">
          {['All', 'Agrochemical', 'Pharmaceutical', 'Industrial'].map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-3 py-1.5 text-xs font-medium rounded-lg transition-colors ${
                selectedCategory === cat
                  ? 'bg-blue-600 text-white shadow-2xs'
                  : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-400'
              }`}
            >
              {cat}
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Ingredient Directory list + Detailed Chemical Inspector */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Left List */}
        <div className="lg:col-span-5 space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search by chemical name, CAS, or formula..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 focus:outline-hidden"
            />
          </div>

          <div className="space-y-2 max-h-[700px] overflow-y-auto pr-1">
            {ingredients.map((ing) => {
              const isSelected = activeIngredient?.id === ing.id;
              return (
                <div
                  key={ing.id}
                  onClick={() => setActiveIngredientId(ing.id)}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer space-y-1.5 ${
                    isSelected
                      ? 'border-blue-600 bg-blue-50/50 dark:bg-blue-950/40 shadow-xs'
                      : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-slate-300 dark:hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-center justify-between text-xs">
                    <span className="font-semibold text-slate-900 dark:text-white">
                      {ing.name}
                    </span>
                    <span className="font-mono text-[11px] text-slate-400">
                      CAS {ing.casNumber}
                    </span>
                  </div>

                  <div className="flex items-center gap-2 text-slate-500 text-[11px] font-mono">
                    <span>{ing.molecularFormula}</span>
                    <span>·</span>
                    <span>{ing.molecularWeight} g/mol</span>
                  </div>

                  <div className="text-[11px] text-slate-500 line-clamp-1">
                    {ing.category}
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Right Detail Pane */}
        {activeIngredient && (
          <div className="lg:col-span-7 space-y-5">
            {/* 2D Skeletal Molecular Visualizer Component */}
            <ChemicalStructureViewer
              name={activeIngredient.name}
              formula={activeIngredient.molecularFormula}
              weight={activeIngredient.molecularWeight}
              smiles={activeIngredient.smiles}
              structureType={activeIngredient.structureSvgType}
            />

            {/* Chemical Identity Card */}
            <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs space-y-4">
              <div className="flex items-start justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
                <div>
                  <h3 className="text-lg font-bold text-slate-900 dark:text-white">
                    {activeIngredient.name}
                  </h3>
                  <div className="text-xs text-slate-500 font-mono mt-0.5">
                    IUPAC: {activeIngredient.iupacName}
                  </div>
                </div>
                <span className="text-xs px-2.5 py-1 rounded-md bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 font-medium">
                  {activeIngredient.category}
                </span>
              </div>

              {/* Chemical Identifiers Grid */}
              <div className="grid grid-cols-2 gap-3 text-xs">
                <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-slate-100 dark:border-slate-800">
                  <div className="text-slate-400 text-[11px]">CAS Registry Number</div>
                  <div className="font-mono font-semibold text-slate-900 dark:text-white mt-0.5 flex items-center justify-between">
                    <span>{activeIngredient.casNumber}</span>
                    <button
                      onClick={() => handleCopy(activeIngredient.casNumber, 'CAS')}
                      className="text-slate-400 hover:text-slate-600"
                    >
                      {copiedKey === 'CAS' ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
                    </button>
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-slate-100 dark:border-slate-800">
                  <div className="text-slate-400 text-[11px]">Molecular Formula</div>
                  <div className="font-mono font-semibold text-slate-900 dark:text-white mt-0.5">
                    {activeIngredient.molecularFormula}
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-slate-100 dark:border-slate-800">
                  <div className="text-slate-400 text-[11px]">Molecular Weight</div>
                  <div className="font-mono font-semibold text-slate-900 dark:text-white mt-0.5">
                    {activeIngredient.molecularWeight} g/mol
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-slate-100 dark:border-slate-800">
                  <div className="text-slate-400 text-[11px]">LogP Partition Coefficient</div>
                  <div className="font-mono font-semibold text-slate-900 dark:text-white mt-0.5">
                    {activeIngredient.logP}
                  </div>
                </div>
              </div>

              {/* SMILES & InChIKey */}
              <div className="space-y-2 text-xs">
                <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-slate-100 dark:border-slate-800">
                  <div className="flex items-center justify-between text-slate-400 text-[11px] mb-1">
                    <span>Canonical SMILES</span>
                    <button
                      onClick={() => handleCopy(activeIngredient.smiles, 'SMILES')}
                      className="text-slate-400 hover:text-slate-600 flex items-center gap-1"
                    >
                      {copiedKey === 'SMILES' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                      <span>Copy</span>
                    </button>
                  </div>
                  <div className="font-mono text-slate-800 dark:text-slate-200 break-all select-all text-[11px]">
                    {activeIngredient.smiles}
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-slate-100 dark:border-slate-800">
                  <div className="flex items-center justify-between text-slate-400 text-[11px] mb-1">
                    <span>InChIKey Hash</span>
                    <button
                      onClick={() => handleCopy(activeIngredient.inchiKey, 'InChIKey')}
                      className="text-slate-400 hover:text-slate-600 flex items-center gap-1"
                    >
                      {copiedKey === 'InChIKey' ? <Check className="w-3 h-3 text-emerald-500" /> : <Copy className="w-3 h-3" />}
                      <span>Copy</span>
                    </button>
                  </div>
                  <div className="font-mono text-slate-800 dark:text-slate-200 select-all text-[11px]">
                    {activeIngredient.inchiKey}
                  </div>
                </div>
              </div>

              {/* Physicochemical Properties */}
              <div>
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">
                  Physicochemical Properties
                </h4>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                  <div className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800">
                    <span className="text-slate-400 text-[11px]">Physical State</span>
                    <div className="font-medium text-slate-800 dark:text-slate-200 mt-0.5 truncate" title={activeIngredient.physicalState}>
                      {activeIngredient.physicalState}
                    </div>
                  </div>
                  <div className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800">
                    <span className="text-slate-400 text-[11px]">Melting Point</span>
                    <div className="font-medium text-slate-800 dark:text-slate-200 mt-0.5">
                      {activeIngredient.meltingPoint}
                    </div>
                  </div>
                  <div className="p-2.5 rounded-lg border border-slate-200 dark:border-slate-800">
                    <span className="text-slate-400 text-[11px]">Water Solubility</span>
                    <div className="font-medium text-slate-800 dark:text-slate-200 mt-0.5">
                      {activeIngredient.waterSolubility}
                    </div>
                  </div>
                </div>
              </div>

              {/* GHS Hazard Statements */}
              {activeIngredient.hazardStatements.length > 0 && (
                <div>
                  <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">
                    GHS Hazard Classifications
                  </h4>
                  <div className="space-y-1.5">
                    {activeIngredient.hazardStatements.map((h, i) => (
                      <div
                        key={i}
                        className="flex items-center gap-2 p-2 rounded-lg bg-amber-500/10 border border-amber-500/20 text-xs text-amber-800 dark:text-amber-300 font-mono"
                      >
                        <AlertTriangle className="w-3.5 h-3.5 shrink-0" />
                        <span>{h}</span>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {/* Associated Commercial Products */}
              <div>
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">
                  Commercial Formulations Containing This Active
                </h4>
                <div className="flex flex-wrap gap-2">
                  {activeIngredient.relatedProductIds.map((pId) => {
                    const prod = DataService.getProductById(pId);
                    if (!prod) return null;
                    return (
                      <button
                        key={pId}
                        onClick={() => onSelectProduct(pId)}
                        className="px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-800 dark:text-slate-200 hover:border-blue-500 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors flex items-center gap-1.5"
                      >
                        <Package className="w-3.5 h-3.5 text-blue-500" />
                        <span>{prod.brandName}</span>
                      </button>
                    );
                  })}
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
