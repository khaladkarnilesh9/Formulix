import React, { useState } from 'react';
import { AdminSidebar, AdminTabKey } from './AdminSidebar';
import { AdminHeader } from './AdminHeader';

interface AdminLayoutProps {
  currentTab: AdminTabKey;
  onTabChange: (tab: AdminTabKey) => void;
  onExitToUserPortal: () => void;
  operatorRole: string;
  onChangeOperatorRole: (role: string) => void;
  children: React.ReactNode;
}

export const AdminLayout: React.FC<AdminLayoutProps> = ({
  currentTab,
  onTabChange,
  onExitToUserPortal,
  operatorRole,
  onChangeOperatorRole,
  children,
}) => {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <div className="min-h-screen bg-slate-50 dark:bg-slate-950 text-slate-900 dark:text-slate-100 flex transition-colors duration-200">
      {/* Desktop Sidebar */}
      <div className="hidden lg:block">
        <AdminSidebar
          currentTab={currentTab}
          onTabChange={onTabChange}
          collapsed={collapsed}
          onToggleCollapse={() => setCollapsed(!collapsed)}
          onExitToUserPortal={onExitToUserPortal}
        />
      </div>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 lg:hidden">
          <div
            className="fixed inset-0 bg-slate-950/70 backdrop-blur-xs"
            onClick={() => setMobileOpen(false)}
          />
          <div className="fixed inset-y-0 left-0 w-64 bg-white dark:bg-slate-950 z-50">
            <AdminSidebar
              currentTab={currentTab}
              onTabChange={(tab) => {
                onTabChange(tab);
                setMobileOpen(false);
              }}
              collapsed={false}
              onToggleCollapse={() => setMobileOpen(false)}
              onExitToUserPortal={onExitToUserPortal}
            />
          </div>
        </div>
      )}

      {/* Main Content Viewport */}
      <div
        className={`flex-1 flex flex-col min-w-0 transition-all duration-300 ${
          collapsed ? 'lg:pl-18' : 'lg:pl-64'
        }`}
      >
        <AdminHeader
          currentTab={currentTab}
          onNavigate={onTabChange}
          onExitToUserPortal={onExitToUserPortal}
          onToggleSidebarMobile={() => setMobileOpen(true)}
          operatorRole={operatorRole}
          onChangeOperatorRole={onChangeOperatorRole}
        />

        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
          {children}
        </main>
      </div>
    </div>
  );
};
