import React, { useState, useMemo } from 'react';
import { DataService, ProductFilterParams } from '../../services/dataService';
import { CommercialProduct } from '../../types';
import { useWorkspaceStore } from '../../stores/workspaceStore';
import { EvidenceBadge, StatusIndicator } from '../../components/common/EvidenceBadge';
import { useToast } from '../../components/common/Toast';
import {
  Search,
  Filter,
  LayoutGrid,
  List,
  Scale,
  Bookmark,
  Download,
  ArrowUpDown,
  ChevronLeft,
  ChevronRight,
  ExternalLink,
  RotateCcw,
  SlidersHorizontal,
  Check,
  Building2,
  Globe2,
  Calendar,
  Layers,
  Sparkles,
} from 'lucide-react';

interface ProductSearchViewProps {
  onSelectProduct: (productId: string) => void;
  onNavigateComparison: () => void;
  initialQuery?: string;
}

export const ProductSearchView: React.FC<ProductSearchViewProps> = ({
  onSelectProduct,
  onNavigateComparison,
  initialQuery = '',
}) => {
  const { toast } = useToast();
  const {
    savedProductIds,
    toggleSavedProduct,
    comparisonProductIds,
    toggleComparisonProduct,
  } = useWorkspaceStore();

  const [searchQuery, setSearchQuery] = useState(initialQuery);
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedFormulationType, setSelectedFormulationType] = useState<string>('All');
  const [selectedCountry, setSelectedCountry] = useState<string>('All');
  const [selectedStatus, setSelectedStatus] = useState<string>('All');
  const [selectedManufacturer, setSelectedManufacturer] = useState<string>('All');
  const [sortBy, setSortBy] = useState<ProductFilterParams['sortBy']>('name');
  const [sortOrder, setSortOrder] = useState<'asc' | 'desc'>('asc');
  const [viewMode, setViewMode] = useState<'grid' | 'table'>('table');
  const [currentPage, setCurrentPage] = useState(1);
  const [showFilterSidebar, setShowFilterSidebar] = useState(true);

  const pageSize = 8;

  // Query filtered data
  const result = useMemo(() => {
    return DataService.getProducts({
      query: searchQuery,
      category: selectedCategory,
      formulationType: selectedFormulationType,
      country: selectedCountry,
      registrationStatus: selectedStatus,
      manufacturer: selectedManufacturer,
      sortBy,
      sortOrder,
      page: currentPage,
      pageSize,
    });
  }, [
    searchQuery,
    selectedCategory,
    selectedFormulationType,
    selectedCountry,
    selectedStatus,
    selectedManufacturer,
    sortBy,
    sortOrder,
    currentPage,
  ]);

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('All');
    setSelectedFormulationType('All');
    setSelectedCountry('All');
    setSelectedStatus('All');
    setSelectedManufacturer('All');
    setCurrentPage(1);
    toast('Filters reset to default view');
  };

  const handleToggleComparison = (product: CommercialProduct) => {
    const success = toggleComparisonProduct(product.id, product.brandName);
    if (!success) {
      toast('Maximum 4 products can be compared simultaneously', 'warning');
    } else {
      const isNowIn = !comparisonProductIds.includes(product.id);
      toast(
        isNowIn
          ? `Added "${product.brandName}" to comparison`
          : `Removed "${product.brandName}" from comparison`
      );
    }
  };

  const handleToggleBookmark = (product: CommercialProduct) => {
    toggleSavedProduct(product.id, product.brandName);
    const isSaved = savedProductIds.includes(product.id);
    toast(
      isSaved
        ? `Removed "${product.brandName}" from saved items`
        : `Saved "${product.brandName}" to your workspace`
    );
  };

  const handleExportCSV = () => {
    const allMatching = DataService.getProducts({
      query: searchQuery,
      category: selectedCategory,
      formulationType: selectedFormulationType,
      country: selectedCountry,
      registrationStatus: selectedStatus,
      manufacturer: selectedManufacturer,
      sortBy,
      sortOrder,
      page: 1,
      pageSize: 1000,
    }).items;

    const headers = [
      'Brand Name',
      'Generic Name',
      'Active Ingredient',
      'CAS Number',
      'Formulation Type',
      'Strength',
      'Manufacturer',
      'Country',
      'Registration Status',
      'Registration Number',
      'Last Verified',
    ];

    const rows = allMatching.map((p) => [
      `"${p.brandName.replace(/"/g, '""')}"`,
      `"${p.genericName.replace(/"/g, '""')}"`,
      `"${p.activeIngredient.replace(/"/g, '""')}"`,
      `"${p.casNumber}"`,
      `"${p.formulationType}"`,
      `"${p.strength}"`,
      `"${p.manufacturerName.replace(/"/g, '""')}"`,
      `"${p.country}"`,
      `"${p.registrationStatus}"`,
      `"${p.registrationNumber}"`,
      `"${p.lastVerifiedDate}"`,
    ]);

    const csvContent = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `formulix_products_${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast(`Exported ${allMatching.length} products to CSV`);
  };

  return (
    <div className="space-y-4 max-w-7xl mx-auto pb-12">
      {/* Search Header Bar */}
      <div className="flex flex-col sm:flex-row items-stretch sm:items-center justify-between gap-3 p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs">
        <div className="relative flex-1">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search by brand name, active ingredient, CAS number, or registration..."
            value={searchQuery}
            onChange={(e) => {
              setSearchQuery(e.target.value);
              setCurrentPage(1);
            }}
            className="w-full pl-9 pr-4 py-2 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950/60 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 focus:outline-hidden focus:border-blue-500"
          />
        </div>

        <div className="flex items-center gap-2">
          {/* Toggle Filter Sidebar Button */}
          <button
            onClick={() => setShowFilterSidebar(!showFilterSidebar)}
            className={`flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium border transition-colors ${
              showFilterSidebar
                ? 'bg-blue-50 dark:bg-blue-950/60 text-blue-700 dark:text-blue-300 border-blue-200 dark:border-blue-800'
                : 'bg-white dark:bg-slate-900 text-slate-700 dark:text-slate-300 border-slate-200 dark:border-slate-800'
            }`}
          >
            <SlidersHorizontal className="w-3.5 h-3.5" />
            <span>Filters</span>
          </button>

          {/* View Mode Toggle */}
          <div className="flex items-center border border-slate-200 dark:border-slate-800 rounded-lg p-0.5 bg-slate-50 dark:bg-slate-950">
            <button
              onClick={() => setViewMode('table')}
              className={`p-1.5 rounded-md ${
                viewMode === 'table'
                  ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-2xs'
                  : 'text-slate-400 hover:text-slate-700'
              }`}
              title="Table Grid View"
            >
              <List className="w-4 h-4" />
            </button>
            <button
              onClick={() => setViewMode('grid')}
              className={`p-1.5 rounded-md ${
                viewMode === 'grid'
                  ? 'bg-white dark:bg-slate-800 text-slate-900 dark:text-white shadow-2xs'
                  : 'text-slate-400 hover:text-slate-700'
              }`}
              title="Card Grid View"
            >
              <LayoutGrid className="w-4 h-4" />
            </button>
          </div>

          {/* Export CSV */}
          <button
            onClick={handleExportCSV}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg text-xs font-medium bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition-colors"
            title="Export filtered records to CSV"
          >
            <Download className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Export</span>
          </button>
        </div>
      </div>

      {/* Main Layout: Filters Sidebar + Results View */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-4 items-start">
        {/* Advanced Filters Sidebar */}
        {showFilterSidebar && (
          <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs space-y-5 lg:sticky lg:top-20">
            <div className="flex items-center justify-between pb-3 border-b border-slate-100 dark:border-slate-800">
              <div className="flex items-center gap-2 text-xs font-bold uppercase tracking-wider text-slate-700 dark:text-slate-300">
                <Filter className="w-3.5 h-3.5 text-blue-500" />
                <span>Refine Search</span>
              </div>
              <button
                onClick={handleResetFilters}
                className="text-[11px] text-slate-500 hover:text-blue-600 dark:hover:text-blue-400 flex items-center gap-1"
              >
                <RotateCcw className="w-3 h-3" />
                <span>Reset</span>
              </button>
            </div>

            {/* Product Category */}
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-600 dark:text-slate-400">
                Industry Sector
              </label>
              <select
                value={selectedCategory}
                onChange={(e) => {
                  setSelectedCategory(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full p-2 text-xs rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 focus:outline-hidden"
              >
                <option value="All">All Sectors</option>
                <option value="Agrochemical">Agrochemicals</option>
                <option value="Pharmaceutical">Pharmaceuticals</option>
                <option value="Industrial">Industrial Chemicals</option>
              </select>
            </div>

            {/* Formulation Type */}
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-600 dark:text-slate-400">
                Formulation Type
              </label>
              <select
                value={selectedFormulationType}
                onChange={(e) => {
                  setSelectedFormulationType(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full p-2 text-xs rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 focus:outline-hidden"
              >
                <option value="All">All Form Types</option>
                <option value="SC">SC — Suspension Concentrate</option>
                <option value="SL">SL — Soluble Liquid</option>
                <option value="WG">WG / WDG — Water Dispersible Granules</option>
                <option value="EC">EC — Emulsifiable Concentrate</option>
                <option value="Tablet">Tablets (Oral Solid)</option>
                <option value="Controlled-release">Controlled-release Matrix</option>
                <option value="Capsule">Capsules & Pellets</option>
                <option value="Coating">Polymer Coatings & Latexes</option>
                <option value="Surfactant">Surfactant Blends & Concentrates</option>
              </select>
            </div>

            {/* Country Jurisdiction */}
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-600 dark:text-slate-400">
                Jurisdiction
              </label>
              <select
                value={selectedCountry}
                onChange={(e) => {
                  setSelectedCountry(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full p-2 text-xs rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 focus:outline-hidden"
              >
                <option value="All">All Countries</option>
                <option value="India">India (CIBRC / CDSCO)</option>
                <option value="United States">United States (EPA / FDA)</option>
                <option value="European Union">European Union (EFSA / EMA / ECHA)</option>
                <option value="United Kingdom">United Kingdom (MHRA / HSE)</option>
                <option value="Germany">Germany (BVL / BfArM)</option>
              </select>
            </div>

            {/* Registration Status */}
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-600 dark:text-slate-400">
                Registration Status
              </label>
              <select
                value={selectedStatus}
                onChange={(e) => {
                  setSelectedStatus(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full p-2 text-xs rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 focus:outline-hidden"
              >
                <option value="All">All Statuses</option>
                <option value="Approved">Approved</option>
                <option value="Active">Active Registration</option>
                <option value="Under Review">Under Review</option>
                <option value="Conditional">Conditional Approval</option>
              </select>
            </div>

            {/* Manufacturer filter */}
            <div className="space-y-1.5">
              <label className="text-xs font-medium text-slate-600 dark:text-slate-400">
                Manufacturer / Registrant
              </label>
              <select
                value={selectedManufacturer}
                onChange={(e) => {
                  setSelectedManufacturer(e.target.value);
                  setCurrentPage(1);
                }}
                className="w-full p-2 text-xs rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200 focus:outline-hidden"
              >
                <option value="All">All Manufacturers</option>
                <option value="Bayer">Bayer CropScience AG</option>
                <option value="Syngenta">Syngenta AG</option>
                <option value="FMC">FMC Corporation</option>
                <option value="Sun Pharmaceutical">Sun Pharmaceutical</option>
                <option value="BASF">BASF SE</option>
                <option value="Dow Chemical">Dow Chemical Company</option>
                <option value="GlaxoSmithKline">GSK plc</option>
                <option value="AstraZeneca">AstraZeneca plc</option>
              </select>
            </div>

            {/* Comparison Quick Status */}
            {comparisonProductIds.length > 0 && (
              <div className="pt-3 border-t border-slate-100 dark:border-slate-800 space-y-2">
                <div className="flex items-center justify-between text-xs">
                  <span className="font-medium text-slate-600 dark:text-slate-400">Comparing</span>
                  <span className="font-mono text-blue-600 dark:text-blue-400 font-bold">
                    {comparisonProductIds.length}/4
                  </span>
                </div>
                <button
                  onClick={onNavigateComparison}
                  className="w-full py-1.5 px-3 rounded-lg bg-blue-600 hover:bg-blue-700 text-white text-xs font-medium flex items-center justify-center gap-1.5 transition-colors"
                >
                  <Scale className="w-3.5 h-3.5" />
                  <span>Launch Matrix Comparison</span>
                </button>
              </div>
            )}
          </div>
        )}

        {/* Results Container */}
        <div className={showFilterSidebar ? 'lg:col-span-3 space-y-4' : 'col-span-1 lg:col-span-4 space-y-4'}>
          {/* Results Summary Bar */}
          <div className="flex items-center justify-between px-3 py-2 rounded-lg bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 text-xs text-slate-500">
            <div>
              Showing <span className="font-mono font-semibold text-slate-900 dark:text-white">{result.items.length}</span> of{' '}
              <span className="font-mono font-semibold text-slate-900 dark:text-white">{result.total}</span> commercial formulations
            </div>

            {/* Sort Dropdown */}
            <div className="flex items-center gap-2">
              <span className="text-slate-400">Sort by:</span>
              <select
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value as any)}
                className="bg-transparent text-slate-800 dark:text-slate-200 font-medium text-xs focus:outline-hidden"
              >
                <option value="name">Brand Name</option>
                <option value="manufacturer">Manufacturer</option>
                <option value="country">Jurisdiction</option>
                <option value="verified">Last Verified</option>
              </select>
              <button
                onClick={() => setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')}
                className="p-1 hover:bg-slate-200 dark:hover:bg-slate-800 rounded text-slate-600 dark:text-slate-400"
                title={`Toggle Sort Order (${sortOrder.toUpperCase()})`}
              >
                <ArrowUpDown className="w-3 h-3" />
              </button>
            </div>
          </div>

          {result.items.length === 0 ? (
            <div className="p-12 text-center rounded-xl border border-dashed border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900">
              <Sparkles className="w-8 h-8 mx-auto text-slate-300 dark:text-slate-600 mb-3" />
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                No commercial products match your filters
              </h3>
              <p className="text-xs text-slate-400 mt-1 max-w-sm mx-auto">
                Try widening your search terms or clicking reset to restore full catalog view.
              </p>
              <button
                onClick={handleResetFilters}
                className="mt-4 px-3 py-1.5 text-xs font-medium bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
              >
                Reset All Filters
              </button>
            </div>
          ) : viewMode === 'table' ? (
            /* Detailed Data Table View */
            <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-2xs">
              <div className="overflow-x-auto">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50/75 dark:bg-slate-950/50 text-slate-400 font-medium uppercase tracking-wider text-[11px]">
                      <th className="py-3 px-3 text-center w-10">Comp</th>
                      <th className="py-3 px-3">Brand & Category</th>
                      <th className="py-3 px-3">Active Ingredient & CAS</th>
                      <th className="py-3 px-3">Formulation & Strength</th>
                      <th className="py-3 px-3">Manufacturer</th>
                      <th className="py-3 px-3">Jurisdiction</th>
                      <th className="py-3 px-3">Status</th>
                      <th className="py-3 px-3 text-right">Actions</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
                    {result.items.map((prod) => {
                      const isCompared = comparisonProductIds.includes(prod.id);
                      const isSaved = savedProductIds.includes(prod.id);

                      return (
                        <tr
                          key={prod.id}
                          className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors group cursor-pointer"
                          onClick={() => onSelectProduct(prod.id)}
                        >
                          {/* Checkbox for comparison */}
                          <td
                            className="py-3 px-3 text-center"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <input
                              type="checkbox"
                              checked={isCompared}
                              onChange={() => handleToggleComparison(prod)}
                              className="rounded border-slate-300 dark:border-slate-700 text-blue-600 focus:ring-0 cursor-pointer"
                              title="Select for comparison"
                            />
                          </td>

                          {/* Brand & Category */}
                          <td className="py-3 px-3">
                            <div className="font-semibold text-slate-900 dark:text-white group-hover:text-blue-600 dark:group-hover:text-blue-400 transition-colors">
                              {prod.brandName}
                            </div>
                            <div className="text-[11px] text-slate-500 flex items-center gap-1.5">
                              <span>{prod.category}</span>
                              <span aria-hidden="true">·</span>
                              <span className="font-mono text-slate-400">{prod.dataSource.split(' ')[0]}</span>
                            </div>
                          </td>

                          {/* Active Ingredient */}
                          <td className="py-3 px-3">
                            <div className="font-medium text-slate-800 dark:text-slate-200">
                              {prod.activeIngredient}
                            </div>
                            <div className="text-[11px] font-mono text-slate-400">
                              CAS {prod.casNumber}
                            </div>
                          </td>

                          {/* Formulation Type & Strength */}
                          <td className="py-3 px-3">
                            <div className="text-slate-800 dark:text-slate-200">
                              {prod.formulationType}
                            </div>
                            <div className="text-[11px] font-mono text-slate-500">
                              {prod.strength}
                            </div>
                          </td>

                          {/* Manufacturer */}
                          <td className="py-3 px-3 text-slate-600 dark:text-slate-300">
                            {prod.manufacturerName}
                          </td>

                          {/* Country */}
                          <td className="py-3 px-3">
                            <div className="text-slate-800 dark:text-slate-200 font-medium">
                              {prod.country}
                            </div>
                            <div className="text-[10px] font-mono text-slate-400 truncate max-w-[120px]">
                              {prod.registrationNumber}
                            </div>
                          </td>

                          {/* Registration Status */}
                          <td className="py-3 px-3">
                            <StatusIndicator status={prod.registrationStatus} />
                          </td>

                          {/* Actions */}
                          <td
                            className="py-3 px-3 text-right"
                            onClick={(e) => e.stopPropagation()}
                          >
                            <div className="flex items-center justify-end gap-1.5">
                              <button
                                onClick={() => handleToggleBookmark(prod)}
                                className={`p-1.5 rounded-md transition-colors ${
                                  isSaved
                                    ? 'text-purple-600 bg-purple-50 dark:bg-purple-950/50'
                                    : 'text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                                }`}
                                title={isSaved ? 'Remove from Saved' : 'Save to Workspace'}
                              >
                                <Bookmark className="w-3.5 h-3.5" />
                              </button>
                              <button
                                onClick={() => onSelectProduct(prod.id)}
                                className="px-2.5 py-1 rounded-md text-xs font-medium bg-blue-50 text-blue-700 hover:bg-blue-100 dark:bg-blue-950/60 dark:text-blue-300 dark:hover:bg-blue-900 transition-colors"
                              >
                                Spec Sheet
                              </button>
                            </div>
                          </td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            /* Card Grid View */
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {result.items.map((prod) => {
                const isCompared = comparisonProductIds.includes(prod.id);
                const isSaved = savedProductIds.includes(prod.id);

                return (
                  <div
                    key={prod.id}
                    className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs hover:border-blue-500/50 transition-colors flex flex-col justify-between space-y-4"
                  >
                    <div>
                      {/* Top metadata row */}
                      <div className="flex items-center justify-between text-xs text-slate-500 pb-2 border-b border-slate-100 dark:border-slate-800/80">
                        <div className="flex items-center gap-1.5">
                          <span>{prod.category}</span>
                          <span aria-hidden="true">·</span>
                          <span>{prod.country}</span>
                        </div>
                        <StatusIndicator status={prod.registrationStatus} />
                      </div>

                      {/* Title & Active Info */}
                      <div className="pt-3">
                        <h4
                          onClick={() => onSelectProduct(prod.id)}
                          className="text-base font-bold text-slate-900 dark:text-white hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer transition-colors"
                        >
                          {prod.brandName}
                        </h4>
                        <div className="text-xs font-medium text-slate-700 dark:text-slate-300 mt-0.5">
                          {prod.genericName}
                        </div>
                        <div className="text-xs font-mono text-slate-400 mt-1">
                          CAS {prod.casNumber} · {prod.strength}
                        </div>
                      </div>

                      {/* Brief description */}
                      <p className="text-xs text-slate-600 dark:text-slate-400 mt-3 line-clamp-2 leading-relaxed">
                        {prod.description}
                      </p>

                      {/* Manufacturer */}
                      <div className="mt-3 flex items-center gap-1.5 text-xs text-slate-600 dark:text-slate-400">
                        <Building2 className="w-3.5 h-3.5 text-slate-400" />
                        <span className="font-medium text-slate-800 dark:text-slate-200">
                          {prod.manufacturerName}
                        </span>
                      </div>
                    </div>

                    {/* Card Footer Actions */}
                    <div className="pt-3 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => handleToggleComparison(prod)}
                          className={`flex items-center gap-1 px-2.5 py-1 rounded-md text-xs font-medium border transition-colors ${
                            isCompared
                              ? 'bg-blue-600 text-white border-blue-600'
                              : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-800'
                          }`}
                        >
                          <Scale className="w-3 h-3" />
                          <span>{isCompared ? 'Comparing' : 'Compare'}</span>
                        </button>

                        <button
                          onClick={() => handleToggleBookmark(prod)}
                          className={`p-1.5 rounded-md border transition-colors ${
                            isSaved
                              ? 'text-purple-600 bg-purple-50 border-purple-200 dark:bg-purple-950/50 dark:border-purple-800'
                              : 'border-slate-200 dark:border-slate-800 text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800'
                          }`}
                          title="Bookmark Product"
                        >
                          <Bookmark className="w-3.5 h-3.5" />
                        </button>
                      </div>

                      <button
                        onClick={() => onSelectProduct(prod.id)}
                        className="px-3 py-1 rounded-md text-xs font-medium bg-blue-50 text-blue-700 hover:bg-blue-100 dark:bg-blue-950/60 dark:text-blue-300 dark:hover:bg-blue-900 transition-colors"
                      >
                        Specification
                      </button>
                    </div>
                  </div>
                );
              })}
            </div>
          )}

          {/* Pagination Controls */}
          {result.totalPages > 1 && (
            <div className="flex items-center justify-between p-3 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs">
              <span className="text-slate-500">
                Page <span className="font-mono font-medium text-slate-900 dark:text-white">{result.page}</span> of{' '}
                <span className="font-mono font-medium text-slate-900 dark:text-white">{result.totalPages}</span>
              </span>
              <div className="flex items-center gap-1.5">
                <button
                  disabled={result.page <= 1}
                  onClick={() => setCurrentPage((p) => Math.max(p - 1, 1))}
                  className="p-1.5 rounded-md border border-slate-200 dark:border-slate-800 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                >
                  <ChevronLeft className="w-3.5 h-3.5" />
                </button>
                <button
                  disabled={result.page >= result.totalPages}
                  onClick={() => setCurrentPage((p) => Math.min(p + 1, result.totalPages))}
                  className="p-1.5 rounded-md border border-slate-200 dark:border-slate-800 disabled:opacity-40 disabled:cursor-not-allowed hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
                >
                  <ChevronRight className="w-3.5 h-3.5" />
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
