import React, { useState } from 'react';
import { DataService } from '../../services/dataService';
import { TechnicalDocument } from '../../types';
import { DocumentViewerModal } from '../../components/common/DocumentViewerModal';
import { useToast } from '../../components/common/Toast';
import {
  FileText,
  Search,
  Filter,
  Download,
  Eye,
  Calendar,
  Building,
  CheckCircle,
  ExternalLink,
  Tag,
  Sparkles,
} from 'lucide-react';

interface PatentDocumentsViewProps {
  onSelectProduct: (productName: string) => void;
  onSelectIngredient: (ingredientName: string) => void;
  selectedDocId?: string;
}

export const PatentDocumentsView: React.FC<PatentDocumentsViewProps> = ({
  onSelectProduct,
  onSelectIngredient,
  selectedDocId,
}) => {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedType, setSelectedType] = useState<string>('All');
  const [previewDocument, setPreviewDocument] = useState<TechnicalDocument | null>(
    selectedDocId ? DataService.getDocuments().find((d) => d.id === selectedDocId) || null : null
  );

  const documents = DataService.getDocuments(searchQuery, selectedType);

  const handleDownload = (doc: TechnicalDocument, e: React.MouseEvent) => {
    e.stopPropagation();
    const content = `FORMULIX DOCUMENT DOSSIER: ${doc.title}\nID: ${doc.documentNumber}\nIssuer: ${doc.issuer}\nDate: ${doc.publicationDate}\nSummary: ${doc.summary}\n`;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = window.document.createElement('a');
    a.href = url;
    a.download = `${doc.documentNumber.replace(/[^a-zA-Z0-9]/g, '_')}_file.txt`;
    a.click();
    URL.revokeObjectURL(url);
    toast(`Downloaded dossier: ${doc.documentNumber}`);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Top Banner */}
      <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-purple-600 dark:text-purple-400">
            <span>PRIOR ART & TECHNICAL DOSSIER REPOSITORY</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">
            Patent & Technical Document Intelligence
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Safety Data Sheets (SDS), Technical Data Sheets (TDS), formulation patents (USPTO/WIPO), and statutory product labels.
          </p>
        </div>

        {/* Type Filter */}
        <div className="flex items-center gap-1.5 flex-wrap">
          {['All', 'Formulation Patent', 'Safety Data Sheet (SDS)', 'Technical Data Sheet (TDS)', 'Product Label', 'Scientific Literature'].map((t) => (
            <button
              key={t}
              onClick={() => setSelectedType(t)}
              className={`px-2.5 py-1 text-xs font-medium rounded-lg transition-colors ${
                selectedType === t
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-400'
              }`}
            >
              {t.replace(/\(.*\)/, '').trim()}
            </button>
          ))}
        </div>
      </div>

      {/* Search Input Bar */}
      <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs">
        <div className="relative">
          <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search dossiers by title, patent number, issuer, or chemical entity..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 focus:outline-hidden"
          />
        </div>
      </div>

      {/* Document Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
        {documents.map((doc) => (
          <div
            key={doc.id}
            onClick={() => setPreviewDocument(doc)}
            className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs hover:border-blue-500/50 cursor-pointer transition-colors flex flex-col justify-between space-y-3"
          >
            <div>
              <div className="flex items-center justify-between text-xs text-slate-400 pb-2 border-b border-slate-100 dark:border-slate-800/80">
                <span className="font-mono text-purple-600 dark:text-purple-400 font-semibold text-[11px]">
                  {doc.type}
                </span>
                <span className="font-mono text-[11px]">{doc.documentNumber}</span>
              </div>

              <div className="pt-2">
                <h3 className="text-sm font-bold text-slate-900 dark:text-white leading-snug hover:text-blue-600 dark:hover:text-blue-400 transition-colors">
                  {doc.title}
                </h3>
                <div className="text-xs text-slate-500 mt-1 flex items-center gap-2">
                  <span>{doc.issuer}</span>
                  <span>·</span>
                  <span className="font-mono">{doc.publicationDate}</span>
                </div>
              </div>

              <p className="text-xs text-slate-600 dark:text-slate-400 mt-2 line-clamp-2 leading-relaxed">
                {doc.summary}
              </p>

              {/* Related entities */}
              <div className="mt-3 flex flex-wrap gap-1.5">
                {doc.relatedProducts.map((p) => (
                  <span
                    key={p}
                    className="px-2 py-0.5 rounded text-[11px] bg-blue-50 text-blue-700 dark:bg-blue-950/50 dark:text-blue-300 font-medium"
                  >
                    {p}
                  </span>
                ))}
                {doc.relatedIngredients.map((i) => (
                  <span
                    key={i}
                    className="px-2 py-0.5 rounded text-[11px] bg-slate-100 text-slate-700 dark:bg-slate-800 dark:text-slate-300 font-medium"
                  >
                    {i}
                  </span>
                ))}
              </div>
            </div>

            <div className="pt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs">
              <span className="font-mono text-[11px] text-slate-400">
                {doc.format} · {doc.fileSize}
              </span>

              <div className="flex items-center gap-2">
                <button
                  onClick={(e) => handleDownload(doc, e)}
                  className="p-1 rounded-md text-slate-400 hover:text-slate-700 dark:hover:text-slate-200"
                  title="Download Document"
                >
                  <Download className="w-3.5 h-3.5" />
                </button>
                <button className="text-xs font-medium text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1">
                  <Eye className="w-3.5 h-3.5" />
                  <span>Preview</span>
                </button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Document Viewer Modal */}
      <DocumentViewerModal
        document={previewDocument}
        onClose={() => setPreviewDocument(null)}
        onSelectProduct={onSelectProduct}
        onSelectIngredient={onSelectIngredient}
      />
    </div>
  );
};
