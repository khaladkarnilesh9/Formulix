import React, { useState } from 'react';
import { DataService } from '../../services/dataService';
import { Manufacturer } from '../../types';
import { useWorkspaceStore } from '../../stores/workspaceStore';
import { useToast } from '../../components/common/Toast';
import {
  Building2,
  Search,
  Globe2,
  Bookmark,
  ExternalLink,
  Tag,
  CheckCircle,
  Package,
  Layers,
  ChevronRight,
  ShieldCheck,
  RotateCcw,
} from 'lucide-react';

interface ManufacturerDirectoryViewProps {
  initialManufacturerId?: string;
  onSelectProduct: (productId: string) => void;
}

export const ManufacturerDirectoryView: React.FC<ManufacturerDirectoryViewProps> = ({
  initialManufacturerId,
  onSelectProduct,
}) => {
  const { toast } = useToast();
  const {
    bookmarkedManufacturerIds,
    toggleBookmarkedManufacturer,
  } = useWorkspaceStore();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCountry, setSelectedCountry] = useState<string>('All');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [activeMfgId, setActiveMfgId] = useState<string>(
    initialManufacturerId || 'mfg-1'
  );

  const manufacturers = DataService.getManufacturers(
    searchQuery,
    selectedCountry,
    selectedCategory
  );

  const activeManufacturer =
    DataService.getManufacturerById(activeMfgId) || manufacturers[0];

  const mfgProducts = activeManufacturer
    ? DataService.getProducts({ manufacturer: activeManufacturer.name }).items
    : [];

  const handleToggleBookmark = (mfg: Manufacturer, e: React.MouseEvent) => {
    e.stopPropagation();
    toggleBookmarkedManufacturer(mfg.id, mfg.name);
    const isBookmarked = bookmarkedManufacturerIds.includes(mfg.id);
    toast(
      isBookmarked
        ? `Removed "${mfg.name}" from bookmarks`
        : `Bookmarked "${mfg.name}"`
    );
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Directory Header Bar */}
      <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-blue-600 dark:text-blue-400">
            <span>GLOBAL CHEMICAL & FORMULATOR DIRECTORY</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">
            Manufacturer & Registrant Intelligence
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Profiles of agrochemical multinationals, API synthesizers, formulation partners, and brand owners.
          </p>
        </div>

        {/* Country filters */}
        <div className="flex items-center gap-1.5 flex-wrap">
          {['All', 'Germany', 'Switzerland', 'United States', 'India', 'United Kingdom'].map((c) => (
            <button
              key={c}
              onClick={() => setSelectedCountry(c)}
              className={`px-2.5 py-1 text-xs font-medium rounded-lg transition-colors ${
                selectedCountry === c
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-600 dark:text-slate-400'
              }`}
            >
              {c}
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Directory Column + Detailed Company Dossier */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Directory List */}
        <div className="lg:col-span-5 space-y-3">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search companies, headquarters, or brands..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 focus:outline-hidden"
            />
          </div>

          <div className="space-y-2 max-h-[720px] overflow-y-auto pr-1">
            {manufacturers.map((mfg) => {
              const isSelected = activeManufacturer?.id === mfg.id;
              const isBookmarked = bookmarkedManufacturerIds.includes(mfg.id);

              return (
                <div
                  key={mfg.id}
                  onClick={() => setActiveMfgId(mfg.id)}
                  className={`p-3.5 rounded-xl border transition-all cursor-pointer space-y-2 ${
                    isSelected
                      ? 'border-blue-600 bg-blue-50/50 dark:bg-blue-950/40 shadow-xs'
                      : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-slate-300 dark:hover:border-slate-700'
                  }`}
                >
                  <div className="flex items-start justify-between gap-2">
                    <div>
                      <h4 className="text-sm font-bold text-slate-900 dark:text-white">
                        {mfg.name}
                      </h4>
                      <div className="text-[11px] text-slate-500 flex items-center gap-1.5 mt-0.5">
                        <Globe2 className="w-3 h-3 text-slate-400" />
                        <span>{mfg.headquarters}</span>
                      </div>
                    </div>

                    <button
                      onClick={(e) => handleToggleBookmark(mfg, e)}
                      className={`p-1 rounded-md ${
                        isBookmarked
                          ? 'text-purple-600 bg-purple-50 dark:bg-purple-950/50'
                          : 'text-slate-400 hover:text-slate-600'
                      }`}
                    >
                      <Bookmark className="w-3.5 h-3.5" />
                    </button>
                  </div>

                  <div className="flex items-center justify-between text-[11px] pt-2 border-t border-slate-100 dark:border-slate-800/80">
                    <span className="text-slate-400 font-mono">
                      {mfg.productCount} Indexed Products
                    </span>
                    <span className="text-blue-600 dark:text-blue-400 font-medium">
                      {mfg.role}
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Company Profile Details */}
        {activeManufacturer && (
          <div className="lg:col-span-7 space-y-5">
            {/* Header Card */}
            <div className="p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs space-y-4">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100 dark:border-slate-800">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 text-xs font-mono text-slate-500">
                    <span>ESTABLISHED {activeManufacturer.founded}</span>
                    <span>·</span>
                    <span className="font-semibold text-blue-600 dark:text-blue-400">{activeManufacturer.role}</span>
                  </div>
                  <h2 className="text-2xl font-bold text-slate-900 dark:text-white">
                    {activeManufacturer.name}
                  </h2>
                  <div className="text-xs text-slate-500 flex items-center gap-1.5">
                    <Globe2 className="w-3.5 h-3.5" />
                    <span>{activeManufacturer.headquarters}</span>
                  </div>
                </div>

                <a
                  href={activeManufacturer.website}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-1.5 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-50 dark:hover:bg-slate-800 transition-colors w-fit"
                >
                  <span>Corporate Site</span>
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>

              {/* Overview */}
              <div>
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-1.5">
                  Corporate Profile & Formulation Capabilities
                </h4>
                <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed">
                  {activeManufacturer.overview}
                </p>
              </div>

              {/* Badges / Metrics */}
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-slate-100 dark:border-slate-800">
                  <div className="text-slate-400 text-[11px]">Primary Sector</div>
                  <div className="font-semibold text-slate-900 dark:text-white mt-0.5 truncate">
                    {activeManufacturer.sector.join(', ')}
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-slate-100 dark:border-slate-800">
                  <div className="text-slate-400 text-[11px]">Commercial Index</div>
                  <div className="font-mono font-semibold text-slate-900 dark:text-white mt-0.5">
                    {activeManufacturer.productCount} Products
                  </div>
                </div>

                <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-slate-100 dark:border-slate-800">
                  <div className="text-slate-400 text-[11px]">Compliance Standards</div>
                  <div className="font-semibold text-emerald-600 dark:text-emerald-400 mt-0.5 truncate">
                    {activeManufacturer.complianceCertifications.join(' · ')}
                  </div>
                </div>
              </div>

              {/* Brand Portfolio */}
              <div>
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-2">
                  Proprietary Commercial Brands
                </h4>
                <div className="flex flex-wrap gap-2">
                  {activeManufacturer.brandPortfolio.map((b) => (
                    <span
                      key={b}
                      className="inline-flex items-center gap-1 px-3 py-1 rounded-md text-xs bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-slate-200 font-medium"
                    >
                      <Tag className="w-3 h-3 text-blue-500" />
                      <span>{b}</span>
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Manufacturer Indexed Products Table */}
            <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs space-y-3">
              <div className="flex items-center justify-between">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                  Formulations by {activeManufacturer.name}
                </h4>
                <span className="text-xs font-mono text-slate-400">
                  {mfgProducts.length} entries shown
                </span>
              </div>

              {mfgProducts.length === 0 ? (
                <div className="p-6 text-center text-xs text-slate-400 border border-slate-100 dark:border-slate-800 rounded-lg">
                  No products filtered for this specific view.
                </div>
              ) : (
                <div className="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-lg">
                  <table className="w-full text-left text-xs border-collapse">
                    <thead>
                      <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-400 font-medium uppercase tracking-wider text-[11px]">
                        <th className="py-2.5 px-3">Brand Name</th>
                        <th className="py-2.5 px-3">Active Substance</th>
                        <th className="py-2.5 px-3">Form Type</th>
                        <th className="py-2.5 px-3">Country</th>
                        <th className="py-2.5 px-3 text-right">Dossier</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                      {mfgProducts.map((p) => (
                        <tr key={p.id} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                          <td className="py-2.5 px-3 font-semibold text-slate-900 dark:text-white">
                            {p.brandName}
                          </td>
                          <td className="py-2.5 px-3 text-slate-700 dark:text-slate-300">
                            {p.activeIngredient}
                          </td>
                          <td className="py-2.5 px-3 text-slate-500">
                            {p.formulationType}
                          </td>
                          <td className="py-2.5 px-3 text-slate-500">
                            {p.country}
                          </td>
                          <td className="py-2.5 px-3 text-right">
                            <button
                              onClick={() => onSelectProduct(p.id)}
                              className="text-xs font-medium text-blue-600 dark:text-blue-400 hover:underline"
                            >
                              Inspect →
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
