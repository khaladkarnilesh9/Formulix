import React, { useState } from 'react';
import { DataService } from '../../services/dataService';
import { useToast } from '../../components/common/Toast';
import {
  Tag,
  Search,
  Building2,
  Package,
  Layers,
  Globe2,
  Sparkles,
  ArrowRight,
  TrendingUp,
} from 'lucide-react';

interface BrandIntelligenceViewProps {
  onSelectProduct: (productId: string) => void;
  onSelectManufacturer: (mfgId: string) => void;
}

export const BrandIntelligenceView: React.FC<BrandIntelligenceViewProps> = ({
  onSelectProduct,
  onSelectManufacturer,
}) => {
  const [searchQuery, setSearchQuery] = useState('');
  const manufacturers = DataService.getManufacturers();
  const products = DataService.getProducts({ pageSize: 50 }).items;

  // Aggregate brand records
  const brandList = manufacturers.flatMap((m) =>
    m.brandPortfolio.map((brandName) => {
      const matchingProduct = products.find(
        (p) => p.brandName.toLowerCase().includes(brandName.toLowerCase())
      );
      return {
        brandName,
        manufacturerId: m.id,
        manufacturerName: m.name,
        country: m.country,
        sector: m.sector[0],
        productId: matchingProduct?.id,
        activeIngredient: matchingProduct?.activeIngredient || 'Proprietary Active Blend',
        formulationType: matchingProduct?.formulationType || 'Commercial Disclosed',
      };
    })
  );

  const filteredBrands = brandList.filter(
    (b) =>
      b.brandName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.manufacturerName.toLowerCase().includes(searchQuery.toLowerCase()) ||
      b.activeIngredient.toLowerCase().includes(searchQuery.toLowerCase())
  );

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Header */}
      <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-blue-600 dark:text-blue-400">
            <span>COMMERCIAL TRADEMARKS & PORTFOLIO MAPPING</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">
            Brand Intelligence & Global Trademarks
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Monitor multinational brand franchises, active substance associations, and company ownership.
          </p>
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
          <input
            type="text"
            placeholder="Search brands or actives..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-9 pr-3 py-1.5 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 focus:outline-hidden"
          />
        </div>
      </div>

      {/* Brand Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {filteredBrands.map((b, idx) => (
          <div
            key={idx}
            className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs hover:border-blue-500/50 transition-colors flex flex-col justify-between space-y-3"
          >
            <div>
              <div className="flex items-center justify-between text-xs text-slate-400 pb-2 border-b border-slate-100 dark:border-slate-800/80">
                <span className="font-mono text-[11px] text-blue-600 dark:text-blue-400 font-semibold">
                  {b.sector}
                </span>
                <span>{b.country}</span>
              </div>

              <div className="pt-2">
                <h3 className="text-base font-bold text-slate-900 dark:text-white flex items-center gap-2">
                  <Tag className="w-4 h-4 text-blue-500" />
                  <span>{b.brandName}</span>
                </h3>
                <div
                  onClick={() => onSelectManufacturer(b.manufacturerId)}
                  className="text-xs text-slate-600 dark:text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer mt-1 flex items-center gap-1 font-medium"
                >
                  <Building2 className="w-3.5 h-3.5 text-slate-400" />
                  <span>{b.manufacturerName}</span>
                </div>
              </div>

              <div className="mt-3 p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-slate-100 dark:border-slate-800/80 text-xs">
                <div className="text-[10px] text-slate-400 uppercase tracking-wider">Associated Active Entity</div>
                <div className="font-medium text-slate-800 dark:text-slate-200 mt-0.5">
                  {b.activeIngredient}
                </div>
                <div className="text-[11px] font-mono text-slate-500 mt-0.5">
                  {b.formulationType}
                </div>
              </div>
            </div>

            <div className="pt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs">
              <span className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium flex items-center gap-1">
                <TrendingUp className="w-3 h-3" />
                <span>Active Trademark</span>
              </span>

              {b.productId ? (
                <button
                  onClick={() => onSelectProduct(b.productId!)}
                  className="font-medium text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1"
                >
                  <span>Inspect Dossier</span>
                  <ArrowRight className="w-3 h-3" />
                </button>
              ) : (
                <button
                  onClick={() => onSelectManufacturer(b.manufacturerId)}
                  className="font-medium text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:underline"
                >
                  Company Profile →
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};
