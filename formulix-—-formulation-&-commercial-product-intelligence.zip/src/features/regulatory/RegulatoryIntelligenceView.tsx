import React, { useState } from 'react';
import { DataService } from '../../services/dataService';
import { RegulatoryRecord } from '../../types';
import { StatusIndicator } from '../../components/common/EvidenceBadge';
import { useToast } from '../../components/common/Toast';
import {
  ShieldCheck,
  Search,
  Filter,
  ExternalLink,
  Calendar,
  Building2,
  FileCheck2,
  Download,
  RotateCcw,
  Sparkles,
} from 'lucide-react';

interface RegulatoryIntelligenceViewProps {
  onSelectProduct: (productId: string) => void;
}

export const RegulatoryIntelligenceView: React.FC<RegulatoryIntelligenceViewProps> = ({
  onSelectProduct,
}) => {
  const { toast } = useToast();
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCountry, setSelectedCountry] = useState<string>('All');
  const [selectedAuthority, setSelectedAuthority] = useState<string>('All');

  const records = DataService.getRegulatoryRecords(
    searchQuery,
    selectedCountry,
    selectedAuthority
  );

  const handleExportRegulatory = () => {
    const headers = [
      'Registration Number',
      'Product Name',
      'Active Substance',
      'Regulatory Authority',
      'Country',
      'Approval Status',
      'Registration Holder',
      'Approval Date',
      'Expiry Date',
      'Official Gazette Dossier',
    ];

    const rows = records.map((r) => [
      `"${r.registrationNumber}"`,
      `"${r.productName}"`,
      `"${r.activeIngredient}"`,
      `"${r.regulatoryAuthority}"`,
      `"${r.country}"`,
      `"${r.approvalStatus}"`,
      `"${r.registrationHolder}"`,
      `"${r.approvalDate}"`,
      `"${r.expiryDate}"`,
      `"${r.sourceDocument}"`,
    ]);

    const csv = [headers.join(','), ...rows.map((r) => r.join(','))].join('\n');
    const blob = new Blob([csv], { type: 'text/csv' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `regulatory_registrations_${Date.now()}.csv`;
    a.click();
    URL.revokeObjectURL(url);
    toast(`Exported ${records.length} regulatory records to CSV`);
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Top Banner */}
      <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
        <div>
          <div className="flex items-center gap-2 text-xs font-mono text-emerald-600 dark:text-emerald-400">
            <span>GOVERNMENT GAZETTE & STATUTORY REGISTERS</span>
          </div>
          <h2 className="text-xl font-bold text-slate-900 dark:text-white">
            Multi-Jurisdiction Regulatory Intelligence
          </h2>
          <p className="text-xs text-slate-500 mt-0.5">
            Audit official registration decisions across India (CIBRC/CDSCO), US (EPA/FDA), and European Union (EFSA/EMA).
          </p>
        </div>

        <button
          onClick={handleExportRegulatory}
          className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium bg-slate-100 hover:bg-slate-200 dark:bg-slate-800 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 transition-colors"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Export Gazette Registry</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs space-y-3">
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search by registration number, product, active substance, or holder..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 focus:outline-hidden"
            />
          </div>

          <div className="flex items-center gap-2 w-full sm:w-auto">
            <select
              value={selectedCountry}
              onChange={(e) => setSelectedCountry(e.target.value)}
              className="p-2 text-xs rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200"
            >
              <option value="All">All Jurisdictions</option>
              <option value="India">India</option>
              <option value="United States">United States</option>
              <option value="European Union">European Union</option>
              <option value="United Kingdom">United Kingdom</option>
            </select>

            <select
              value={selectedAuthority}
              onChange={(e) => setSelectedAuthority(e.target.value)}
              className="p-2 text-xs rounded-lg bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 text-slate-800 dark:text-slate-200"
            >
              <option value="All">All Authorities</option>
              <option value="CIBRC">CIBRC (Agro India)</option>
              <option value="EPA">US EPA (Agro / TSCA)</option>
              <option value="FDA">US FDA (Pharma)</option>
              <option value="EFSA">EFSA / Member State (EU)</option>
              <option value="EMA">EMA (EU Pharma)</option>
              <option value="MHRA">MHRA (UK)</option>
            </select>
          </div>
        </div>
      </div>

      {/* Regulatory Table */}
      <div className="rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs border-collapse">
            <thead>
              <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-400 font-medium uppercase tracking-wider text-[11px]">
                <th className="py-3 px-4">Registration No.</th>
                <th className="py-3 px-4">Commercial Brand</th>
                <th className="py-3 px-4">Active Substance</th>
                <th className="py-3 px-4">Regulatory Authority</th>
                <th className="py-3 px-4">Holder</th>
                <th className="py-3 px-4">Status & Validity</th>
                <th className="py-3 px-4 text-right">Gazette / Link</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
              {records.map((reg) => (
                <tr key={reg.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors">
                  <td className="py-3.5 px-4 font-mono font-semibold text-slate-900 dark:text-white">
                    {reg.registrationNumber}
                  </td>
                  <td className="py-3.5 px-4">
                    <button
                      onClick={() => onSelectProduct(reg.productId)}
                      className="font-semibold text-slate-900 dark:text-white hover:text-blue-600 dark:hover:text-blue-400 hover:underline text-left"
                    >
                      {reg.productName}
                    </button>
                    <div className="text-[11px] text-slate-400">{reg.country}</div>
                  </td>
                  <td className="py-3.5 px-4 text-slate-700 dark:text-slate-300">
                    {reg.activeIngredient}
                  </td>
                  <td className="py-3.5 px-4">
                    <div className="font-medium text-slate-800 dark:text-slate-200">
                      {reg.regulatoryAuthority}
                    </div>
                    <div className="text-[10px] text-slate-400 truncate max-w-[200px]" title={reg.sourceDocument}>
                      {reg.sourceDocument}
                    </div>
                  </td>
                  <td className="py-3.5 px-4 text-slate-600 dark:text-slate-300">
                    {reg.registrationHolder}
                  </td>
                  <td className="py-3.5 px-4 space-y-1">
                    <StatusIndicator status={reg.approvalStatus} />
                    <div className="font-mono text-[10px] text-slate-500">
                      Exp: {reg.expiryDate}
                    </div>
                  </td>
                  <td className="py-3.5 px-4 text-right">
                    <a
                      href={reg.officialLink}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="inline-flex items-center gap-1 text-xs text-blue-600 dark:text-blue-400 hover:underline"
                    >
                      <span>Authority Portal</span>
                      <ExternalLink className="w-3 h-3" />
                    </a>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
