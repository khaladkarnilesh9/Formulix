import React, { useState } from 'react';
import { DataService, FormulationFilterParams } from '../../services/dataService';
import { Formulation } from '../../types';
import { useWorkspaceStore } from '../../stores/workspaceStore';
import { EvidenceBadge } from '../../components/common/EvidenceBadge';
import { useToast } from '../../components/common/Toast';
import {
  FlaskConical,
  Search,
  Filter,
  Layers,
  Sparkles,
  Bookmark,
  CheckCircle2,
  ExternalLink,
  ChevronRight,
  X,
  FileText,
  SlidersHorizontal,
  RotateCcw,
  ShieldAlert,
  ArrowRight,
  Eye,
} from 'lucide-react';

interface FormulationIntelligenceViewProps {
  initialFormulationId?: string;
  onSelectProduct: (productId: string) => void;
  onSelectIngredient: (casOrId: string) => void;
}

export const FormulationIntelligenceView: React.FC<FormulationIntelligenceViewProps> = ({
  initialFormulationId,
  onSelectProduct,
  onSelectIngredient,
}) => {
  const { toast } = useToast();
  const { savedFormulationIds, toggleSavedFormulation } = useWorkspaceStore();

  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('All');
  const [selectedType, setSelectedType] = useState<string>('All');
  const [selectedFunction, setSelectedFunction] = useState<string>('All');
  const [activeFormulationId, setActiveFormulationId] = useState<string | null>(
    initialFormulationId || null
  );

  const formulations = DataService.getFormulations({
    query: searchQuery,
    category: selectedCategory,
    formulationType: selectedType,
    ingredientFunction: selectedFunction,
  });

  const selectedFormulation = activeFormulationId
    ? DataService.getFormulationById(activeFormulationId)
    : null;

  const handleToggleSave = (form: Formulation, e: React.MouseEvent) => {
    e.stopPropagation();
    toggleSavedFormulation(form.id, form.name);
    const isSaved = savedFormulationIds.includes(form.id);
    toast(
      isSaved
        ? `Removed "${form.name}" from saved formulations`
        : `Saved formulation recipe "${form.name}"`
    );
  };

  const handleResetFilters = () => {
    setSearchQuery('');
    setSelectedCategory('All');
    setSelectedType('All');
    setSelectedFunction('All');
    toast('Formulation filters reset');
  };

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-16">
      {/* Disclaimer banner */}
      <div className="flex items-start gap-3 p-4 rounded-xl border border-blue-200 dark:border-blue-900/50 bg-blue-50/60 dark:bg-blue-950/30 text-xs text-blue-900 dark:text-blue-300">
        <Sparkles className="w-4 h-4 text-blue-600 dark:text-blue-400 shrink-0 mt-0.5" />
        <div className="leading-relaxed">
          <span className="font-semibold">Synthetic Formulation Intelligence Engine: </span>
          Recipes and manufacturing sequences are curated synthetic models derived from public patents (USPTO, WIPO), FAO/WHO specifications, and scientific pharmacopeial literature for evaluation and formulation discovery. Formulix does not disclose proprietary manufacturer secrets.
        </div>
      </div>

      {/* Top Search & Filter Bar */}
      <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs space-y-3">
        <div className="flex flex-col sm:flex-row items-center gap-3">
          <div className="relative flex-1 w-full">
            <Search className="w-4 h-4 absolute left-3.5 top-1/2 -translate-y-1/2 text-slate-400" />
            <input
              type="text"
              placeholder="Search recipes by active ingredient, patent number, or application..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 text-xs sm:text-sm bg-slate-50 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 rounded-lg text-slate-900 dark:text-white placeholder-slate-400 focus:outline-hidden"
            />
          </div>

          <button
            onClick={handleResetFilters}
            className="text-xs text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 flex items-center gap-1.5 px-3 py-2 rounded-lg border border-slate-200 dark:border-slate-800 transition-colors whitespace-nowrap"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Filters</span>
          </button>
        </div>

        {/* Quick Sector & Formulation Filter Chips */}
        <div className="flex flex-wrap items-center gap-2 pt-2 border-t border-slate-100 dark:border-slate-800 text-xs">
          <span className="text-slate-400 text-[11px] font-medium mr-1">Sector:</span>
          {['All', 'Agrochemical', 'Pharmaceutical', 'Industrial'].map((cat) => (
            <button
              key={cat}
              onClick={() => setSelectedCategory(cat)}
              className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                selectedCategory === cat
                  ? 'bg-blue-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
              }`}
            >
              {cat}
            </button>
          ))}

          <span className="text-slate-400 text-[11px] font-medium ml-3 mr-1">Type:</span>
          {['All', 'SC', 'SL', 'WG', 'Tablets', 'Controlled-release', 'Capsules', 'Coatings', 'Surfactant'].map((t) => (
            <button
              key={t}
              onClick={() => setSelectedType(t)}
              className={`px-2.5 py-1 rounded-md font-medium transition-colors ${
                selectedType === t
                  ? 'bg-purple-600 text-white'
                  : 'bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-200'
              }`}
            >
              {t}
            </button>
          ))}
        </div>
      </div>

      {/* Main Grid: Formulations List + Detail Panel */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 items-start">
        {/* Formulations List Column */}
        <div className={selectedFormulation ? 'lg:col-span-5 space-y-3' : 'lg:col-span-12 space-y-3'}>
          <div className="flex items-center justify-between text-xs text-slate-500 px-1">
            <span>Indexed Formulations ({formulations.length})</span>
            <span className="font-mono text-[11px]">Click a card to inspect recipe</span>
          </div>

          <div className="space-y-3">
            {formulations.map((form) => {
              const isSelected = activeFormulationId === form.id;
              const isSaved = savedFormulationIds.includes(form.id);

              return (
                <div
                  key={form.id}
                  onClick={() => setActiveFormulationId(form.id)}
                  className={`p-4 rounded-xl border transition-all cursor-pointer flex flex-col justify-between space-y-3 ${
                    isSelected
                      ? 'border-blue-600 bg-blue-50/40 dark:bg-blue-950/30 shadow-xs'
                      : 'border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 hover:border-slate-300 dark:hover:border-slate-700'
                  }`}
                >
                  <div className="space-y-1.5">
                    <div className="flex items-center justify-between text-xs">
                      <div className="flex items-center gap-1.5 text-slate-500 text-[11px]">
                        <span className="font-semibold text-blue-600 dark:text-blue-400">{form.category}</span>
                        <span aria-hidden="true">·</span>
                        <span>{form.formulationType}</span>
                      </div>
                      <button
                        onClick={(e) => handleToggleSave(form, e)}
                        className={`p-1 rounded-md ${
                          isSaved
                            ? 'text-purple-600 bg-purple-50 dark:bg-purple-950/50'
                            : 'text-slate-400 hover:text-slate-600'
                        }`}
                        title="Save Recipe"
                      >
                        <Bookmark className="w-3.5 h-3.5" />
                      </button>
                    </div>

                    <h3 className="text-sm font-bold text-slate-900 dark:text-white leading-snug">
                      {form.name}
                    </h3>

                    <p className="text-xs text-slate-600 dark:text-slate-400 line-clamp-2 leading-relaxed">
                      {form.intendedApplication}
                    </p>
                  </div>

                  <div className="pt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-[11px]">
                    <span className="text-slate-400 font-mono">
                      {form.composition.length} Ingredients · {form.properties.shelfLife}
                    </span>
                    <span className="font-medium text-blue-600 dark:text-blue-400 flex items-center gap-1">
                      <span>Recipe Specs</span>
                      <ChevronRight className="w-3 h-3" />
                    </span>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Selected Formulation Comprehensive Detail Panel */}
        {selectedFormulation && (
          <div className="lg:col-span-7 p-6 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs space-y-6">
            {/* Header */}
            <div className="flex items-start justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
              <div className="space-y-1">
                <div className="flex items-center gap-2 text-xs text-slate-500 font-mono">
                  <span className="font-semibold text-blue-600 dark:text-blue-400">{selectedFormulation.category}</span>
                  <span>·</span>
                  <span>{selectedFormulation.formulationType}</span>
                </div>
                <h2 className="text-xl font-bold text-slate-900 dark:text-white">
                  {selectedFormulation.name}
                </h2>
                <div className="text-xs text-slate-500">
                  Target: {selectedFormulation.targetIndustry}
                </div>
              </div>

              <button
                onClick={() => setActiveFormulationId(null)}
                className="p-1 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Synthetic demo notice */}
            <div className="p-3 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-slate-100 dark:border-slate-800 text-xs text-slate-600 dark:text-slate-400 space-y-1">
              <div className="font-semibold text-slate-800 dark:text-slate-200 flex items-center gap-1.5">
                <Sparkles className="w-3.5 h-3.5 text-purple-500" />
                <span>Reference Source & Protocol Verification</span>
              </div>
              <div className="font-mono text-[11px] text-slate-500">
                {selectedFormulation.sourceReference}
              </div>
            </div>

            {/* Intended Application */}
            <div>
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-1.5">
                Intended Application & Target Use
              </h4>
              <p className="text-xs text-slate-700 dark:text-slate-300 leading-relaxed bg-slate-50/50 dark:bg-slate-950/40 p-3 rounded-lg border border-slate-100 dark:border-slate-800">
                {selectedFormulation.intendedApplication}
              </p>
            </div>

            {/* Composition Table */}
            <div>
              <div className="flex items-center justify-between mb-2">
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                  Formulation Composition Table
                </h4>
                <span className="text-xs font-mono text-slate-400">
                  {selectedFormulation.composition.length} Components
                </span>
              </div>

              <div className="overflow-x-auto border border-slate-200 dark:border-slate-800 rounded-lg">
                <table className="w-full text-left text-xs border-collapse">
                  <thead>
                    <tr className="border-b border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950 text-slate-400 font-medium uppercase tracking-wider text-[11px]">
                      <th className="py-2.5 px-3">Ingredient</th>
                      <th className="py-2.5 px-3">CAS</th>
                      <th className="py-2.5 px-3">Chemical Function</th>
                      <th className="py-2.5 px-3">Concentration</th>
                      <th className="py-2.5 px-3">Category</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-100 dark:divide-slate-800">
                    {selectedFormulation.composition.map((item, idx) => (
                      <tr key={idx} className="hover:bg-slate-50 dark:hover:bg-slate-800/40">
                        <td className="py-2.5 px-3 font-semibold text-slate-900 dark:text-white">
                          <button
                            onClick={() => onSelectIngredient(item.cas)}
                            className="hover:underline text-left hover:text-blue-600 dark:hover:text-blue-400"
                          >
                            {item.ingredient}
                          </button>
                        </td>
                        <td className="py-2.5 px-3 font-mono text-slate-500">
                          {item.cas}
                        </td>
                        <td className="py-2.5 px-3 text-slate-700 dark:text-slate-300">
                          {item.chemicalFunction}
                        </td>
                        <td className="py-2.5 px-3 font-mono font-medium text-slate-900 dark:text-white">
                          {item.concentration} {item.unit}
                        </td>
                        <td className="py-2.5 px-3 text-slate-500">
                          {item.ingredientCategory}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Manufacturing Information & Sequence */}
            <div className="space-y-3">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500">
                Manufacturing Unit Operations & Sequence
              </h4>

              <div className="p-3.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/50 space-y-3 text-xs">
                <div className="leading-relaxed text-slate-700 dark:text-slate-300">
                  <span className="font-semibold text-slate-900 dark:text-white">Process Flow: </span>
                  {selectedFormulation.manufacturingInfo.processOverview}
                </div>

                <div className="space-y-1.5 pt-2 border-t border-slate-200 dark:border-slate-800">
                  <div className="font-semibold text-slate-800 dark:text-slate-200 text-[11px] uppercase tracking-wider">
                    Mixing Protocol Sequence:
                  </div>
                  <ol className="list-decimal pl-4 space-y-1 text-slate-600 dark:text-slate-400 leading-relaxed">
                    {selectedFormulation.manufacturingInfo.mixingSequence.map((step, sIdx) => (
                      <li key={sIdx}>{step}</li>
                    ))}
                  </ol>
                </div>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-slate-200 dark:border-slate-800 text-[11px]">
                  <div>
                    <span className="font-semibold text-slate-800 dark:text-slate-200">Critical Parameters:</span>
                    <ul className="list-disc pl-4 text-slate-500 mt-0.5 space-y-0.5">
                      {selectedFormulation.manufacturingInfo.processingConditions.map((c, i) => (
                        <li key={i}>{c}</li>
                      ))}
                    </ul>
                  </div>

                  <div>
                    <span className="font-semibold text-slate-800 dark:text-slate-200">QC Release Limits:</span>
                    <ul className="list-disc pl-4 text-slate-500 mt-0.5 space-y-0.5">
                      {selectedFormulation.manufacturingInfo.qcParameters.map((q, i) => (
                        <li key={i}>{q}</li>
                      ))}
                    </ul>
                  </div>
                </div>
              </div>
            </div>

            {/* Formulation Properties */}
            <div>
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">
                Physicochemical Stability & Finished Properties
              </h4>

              <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 text-xs">
                <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60">
                  <span className="text-slate-400 text-[11px]">pH</span>
                  <div className="font-semibold font-mono text-slate-900 dark:text-white mt-0.5">
                    {selectedFormulation.properties.ph}
                  </div>
                </div>

                <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60">
                  <span className="text-slate-400 text-[11px]">Viscosity</span>
                  <div className="font-semibold font-mono text-slate-900 dark:text-white mt-0.5">
                    {selectedFormulation.properties.viscosity}
                  </div>
                </div>

                <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60">
                  <span className="text-slate-400 text-[11px]">Density</span>
                  <div className="font-semibold font-mono text-slate-900 dark:text-white mt-0.5">
                    {selectedFormulation.properties.density}
                  </div>
                </div>

                <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60">
                  <span className="text-slate-400 text-[11px]">Particle Size</span>
                  <div className="font-semibold font-mono text-slate-900 dark:text-white mt-0.5">
                    {selectedFormulation.properties.particleSize}
                  </div>
                </div>

                <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60">
                  <span className="text-slate-400 text-[11px]">Shelf Life</span>
                  <div className="font-semibold font-mono text-slate-900 dark:text-white mt-0.5">
                    {selectedFormulation.properties.shelfLife}
                  </div>
                </div>

                <div className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950/60">
                  <span className="text-slate-400 text-[11px]">Appearance</span>
                  <div className="font-semibold text-slate-900 dark:text-white mt-0.5 truncate" title={selectedFormulation.properties.appearance}>
                    {selectedFormulation.properties.appearance}
                  </div>
                </div>
              </div>
            </div>

            {/* Patent References */}
            {selectedFormulation.patentReferences.length > 0 && (
              <div>
                <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">
                  Linked Patent Specifications
                </h4>

                <div className="space-y-2">
                  {selectedFormulation.patentReferences.map((pat, idx) => (
                    <div
                      key={idx}
                      className="p-3 rounded-lg border border-slate-200 dark:border-slate-800 text-xs space-y-1 bg-slate-50 dark:bg-slate-950/60"
                    >
                      <div className="flex items-center justify-between">
                        <span className="font-mono font-semibold text-purple-600 dark:text-purple-400">
                          {pat.patentNumber}
                        </span>
                        <a
                          href={pat.url}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="text-blue-600 dark:text-blue-400 hover:underline flex items-center gap-1 text-[11px]"
                        >
                          <span>Google Patents</span>
                          <ExternalLink className="w-3 h-3" />
                        </a>
                      </div>
                      <div className="font-medium text-slate-900 dark:text-slate-100">
                        {pat.title}
                      </div>
                      <div className="text-slate-500 text-[11px]">
                        {pat.relevantExample}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
