import React from 'react';
import { DataService } from '../../services/dataService';
import { useWorkspaceStore } from '../../stores/workspaceStore';
import { EvidenceBadge, StatusIndicator } from '../../components/common/EvidenceBadge';
import {
  Package,
  FlaskConical,
  Atom,
  Building2,
  ShieldCheck,
  FileText,
  TrendingUp,
  ArrowUpRight,
  ExternalLink,
  Search,
  Globe2,
  Clock,
  Sparkles,
  ChevronRight,
} from 'lucide-react';
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';

interface DashboardViewProps {
  onNavigate: (module: string, itemId?: string) => void;
  onOpenSearch: () => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ onNavigate, onOpenSearch }) => {
  const data = DataService.getDashboardMetrics();
  const { recentActivities } = useWorkspaceStore();

  const PIE_COLORS = ['#2563EB', '#7C3AED', '#3B82F6', '#6366F1'];

  return (
    <div className="space-y-6 max-w-7xl mx-auto pb-12">
      {/* Welcome & Quick Exploration Bar */}
      <div className="p-6 rounded-xl border border-blue-200 dark:border-slate-800 bg-linear-to-r from-blue-700 via-blue-800 to-indigo-900 dark:from-slate-900 dark:via-blue-950 dark:to-slate-900 text-white shadow-sm flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="space-y-1">
          <div className="flex items-center gap-2 text-xs font-mono text-blue-200 dark:text-blue-400">
            <span>ENTERPRISE SCIENTIFIC BENCHMARK</span>
            <span>·</span>
            <span>MULTI-SECTOR PLATFORM</span>
          </div>
          <h2 className="text-xl sm:text-2xl font-bold tracking-tight">
            Formulation & Commercial Product Intelligence
          </h2>
          <p className="text-xs sm:text-sm text-blue-100 dark:text-slate-300 max-w-2xl leading-relaxed">
            Cross-industry repository tracking chemical recipes, regulatory approval gazettes, active substance specs, and manufacturing unit operations.
          </p>
        </div>

        <div className="flex items-center gap-2.5 w-full md:w-auto">
          <button
            onClick={onOpenSearch}
            className="flex-1 md:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-blue-600 hover:bg-blue-500 font-medium text-xs text-white shadow-sm transition-colors"
          >
            <Search className="w-4 h-4" />
            <span>Universal Search (⌘K)</span>
          </button>
          <button
            onClick={() => onNavigate('product-search')}
            className="flex-1 md:flex-initial inline-flex items-center justify-center gap-2 px-4 py-2.5 rounded-lg bg-white/10 hover:bg-white/15 border border-white/20 font-medium text-xs text-white transition-colors"
          >
            <span>Product Catalog</span>
            <ArrowUpRight className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* KPI Cards Grid */}
      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3">
        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span>Products</span>
            <Package className="w-4 h-4 text-blue-500" />
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-white">
            {data.kpis.totalProducts.toLocaleString()}
          </div>
          <div className="text-[11px] text-emerald-600 dark:text-emerald-400 font-medium flex items-center gap-1">
            <TrendingUp className="w-3 h-3" />
            <span>+14.2% active indexed</span>
          </div>
        </div>

        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span>Formulations</span>
            <FlaskConical className="w-4 h-4 text-purple-500" />
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-white">
            {data.kpis.totalFormulations.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500">
            Across 24 form types
          </div>
        </div>

        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span>Active Ingredients</span>
            <Atom className="w-4 h-4 text-indigo-500" />
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-white">
            {data.kpis.totalActiveIngredients.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500">
            Verified CAS Registry
          </div>
        </div>

        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span>Manufacturers</span>
            <Building2 className="w-4 h-4 text-amber-500" />
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-white">
            {data.kpis.totalManufacturers.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500">
            Global MNCs & Formulators
          </div>
        </div>

        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span>Registrations</span>
            <ShieldCheck className="w-4 h-4 text-emerald-500" />
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-white">
            {data.kpis.totalRegistrations.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500">
            CIBRC, EPA, EMA, FDA
          </div>
        </div>

        <div className="p-4 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs space-y-2">
          <div className="flex items-center justify-between text-slate-500 text-xs">
            <span>Patent Linked</span>
            <FileText className="w-4 h-4 text-sky-500" />
          </div>
          <div className="text-2xl font-bold font-mono tabular-nums text-slate-900 dark:text-white">
            {data.kpis.patentLinkedFormulations.toLocaleString()}
          </div>
          <div className="text-[11px] text-slate-500">
            74% Prior art linked
          </div>
        </div>
      </div>

      {/* Analytics Charts Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Category Share Donut */}
        <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs flex flex-col justify-between">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Sector Portfolio Distribution
              </h3>
              <p className="text-xs text-slate-500">Active formulations across industry sectors</p>
            </div>
            <span className="text-xs font-mono text-slate-400">N = 100%</span>
          </div>

          <div className="h-48 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <PieChart>
                <Pie
                  data={data.categoryDistribution}
                  dataKey="count"
                  nameKey="name"
                  cx="50%"
                  cy="50%"
                  innerRadius={50}
                  outerRadius={75}
                  paddingAngle={4}
                >
                  {data.categoryDistribution.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={PIE_COLORS[index % PIE_COLORS.length]} />
                  ))}
                </Pie>
                <Tooltip
                  formatter={(val: any) => [`${val}%`, 'Share']}
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    borderRadius: '8px',
                    fontSize: '12px',
                    color: '#fff',
                  }}
                />
              </PieChart>
            </ResponsiveContainer>
          </div>

          <div className="space-y-2 pt-2 border-t border-slate-100 dark:border-slate-800">
            {data.categoryDistribution.map((item, idx) => (
              <div key={item.name} className="flex items-center justify-between text-xs">
                <span className="flex items-center gap-2 text-slate-600 dark:text-slate-300">
                  <span
                    className="w-2.5 h-2.5 rounded-sm"
                    style={{ backgroundColor: PIE_COLORS[idx] }}
                  />
                  <span>{item.name}</span>
                </span>
                <span className="font-mono font-medium text-slate-900 dark:text-white">
                  {item.share}
                </span>
              </div>
            ))}
          </div>
        </div>

        {/* Formulation Type Volume Bar Chart */}
        <div className="lg:col-span-2 p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Formulation Type Representation
              </h3>
              <p className="text-xs text-slate-500">Agrochemical, pharmaceutical, and industrial coating recipes</p>
            </div>
            <button
              onClick={() => onNavigate('formulation-explorer')}
              className="text-xs text-blue-600 dark:text-blue-400 font-medium hover:underline inline-flex items-center gap-1"
            >
              <span>Explore All</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="h-60 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart
                data={data.formulationTypeDistribution}
                margin={{ top: 10, right: 10, left: -20, bottom: 20 }}
              >
                <XAxis
                  dataKey="type"
                  tick={{ fontSize: 10, fill: '#64748b' }}
                  interval={0}
                  angle={-15}
                  textAnchor="end"
                />
                <YAxis tick={{ fontSize: 10, fill: '#64748b' }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: '#0f172a',
                    borderColor: '#334155',
                    borderRadius: '8px',
                    fontSize: '12px',
                    color: '#fff',
                  }}
                />
                <Bar dataKey="count" fill="#2563EB" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>
      </div>

      {/* Global Country-wise Product Coverage & Regulatory Authorities */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Country-wise Commercial Coverage
              </h3>
              <p className="text-xs text-slate-500">Tracked products and registrations per jurisdiction</p>
            </div>
            <Globe2 className="w-4 h-4 text-slate-400" />
          </div>

          <div className="space-y-3">
            {data.countryCoverage.map((c) => (
              <div
                key={c.country}
                className="flex items-center justify-between p-2.5 rounded-lg bg-slate-50 dark:bg-slate-950/60 border border-slate-100 dark:border-slate-800/80 text-xs"
              >
                <div className="flex items-center gap-2 font-medium text-slate-800 dark:text-slate-200">
                  <span className="w-5 h-5 rounded-full bg-slate-200 dark:bg-slate-800 font-mono text-[10px] flex items-center justify-center font-bold text-slate-700 dark:text-slate-300">
                    {c.flag}
                  </span>
                  <span>{c.country}</span>
                </div>
                <div className="flex items-center gap-3 font-mono">
                  <span className="text-slate-600 dark:text-slate-400">
                    {c.products} prods
                  </span>
                  <span className="text-emerald-600 dark:text-emerald-400 font-semibold">
                    {c.registrations} regs
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Recent Product Intelligence Updates */}
        <div className="lg:col-span-2 p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs">
          <div className="flex items-center justify-between mb-4">
            <div>
              <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
                Recent Product Intelligence Records
              </h3>
              <p className="text-xs text-slate-500">Newly indexed registrations and formulation dossiers</p>
            </div>
            <button
              onClick={() => onNavigate('product-search')}
              className="text-xs text-blue-600 dark:text-blue-400 font-medium hover:underline inline-flex items-center gap-1"
            >
              <span>View Full Grid</span>
              <ChevronRight className="w-3.5 h-3.5" />
            </button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs border-collapse">
              <thead>
                <tr className="border-b border-slate-200 dark:border-slate-800 text-slate-400 font-medium uppercase tracking-wider text-[11px]">
                  <th className="py-2.5 px-3">Commercial Brand</th>
                  <th className="py-2.5 px-3">Active Ingredient</th>
                  <th className="py-2.5 px-3">Formulation Type</th>
                  <th className="py-2.5 px-3">Manufacturer</th>
                  <th className="py-2.5 px-3">Status</th>
                  <th className="py-2.5 px-3 text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
                {data.recentUpdates.map((prod) => (
                  <tr
                    key={prod.id}
                    className="hover:bg-slate-50/80 dark:hover:bg-slate-800/50 transition-colors"
                  >
                    <td className="py-3 px-3">
                      <div className="font-semibold text-slate-900 dark:text-white">
                        {prod.brandName}
                      </div>
                      <div className="text-[11px] text-slate-500 font-mono">
                        {prod.country} · {prod.strength}
                      </div>
                    </td>
                    <td className="py-3 px-3">
                      <div className="font-medium text-slate-800 dark:text-slate-200">
                        {prod.activeIngredient}
                      </div>
                      <div className="text-[11px] font-mono text-slate-500">
                        CAS {prod.casNumber}
                      </div>
                    </td>
                    <td className="py-3 px-3 text-slate-600 dark:text-slate-400">
                      {prod.formulationType}
                    </td>
                    <td className="py-3 px-3 text-slate-600 dark:text-slate-400">
                      {prod.manufacturerName}
                    </td>
                    <td className="py-3 px-3">
                      <StatusIndicator status={prod.registrationStatus} />
                    </td>
                    <td className="py-3 px-3 text-right">
                      <button
                        onClick={() => onNavigate('product-detail', prod.id)}
                        className="px-2.5 py-1 text-xs font-medium rounded-md bg-slate-100 hover:bg-blue-50 dark:bg-slate-800 dark:hover:bg-blue-950/60 text-slate-700 hover:text-blue-600 dark:text-slate-300 dark:hover:text-blue-400 transition-colors"
                      >
                        Dossier
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Recent Activity Stream */}
      <div className="p-5 rounded-xl border border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 shadow-2xs">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center gap-2">
            <Clock className="w-4 h-4 text-blue-500" />
            <h3 className="text-sm font-semibold text-slate-900 dark:text-white">
              Recent Intelligence Activity & Audit Trail
            </h3>
          </div>
          <button
            onClick={() => onNavigate('research-workspace')}
            className="text-xs text-blue-600 dark:text-blue-400 hover:underline"
          >
            Go to Research Workspace
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3">
          {recentActivities.slice(0, 6).map((act) => (
            <div
              key={act.id}
              className="p-3 rounded-lg border border-slate-200 dark:border-slate-800/80 bg-slate-50/50 dark:bg-slate-950/40 text-xs flex flex-col justify-between"
            >
              <div className="space-y-1">
                <div className="flex items-center justify-between text-slate-400 text-[11px]">
                  <span className="font-medium text-blue-600 dark:text-blue-400">{act.action}</span>
                  <span className="font-mono">{act.timestamp}</span>
                </div>
                <div className="font-semibold text-slate-800 dark:text-slate-200 truncate">
                  {act.targetName}
                </div>
              </div>
              <div className="text-[10px] text-slate-400 pt-2 mt-2 border-t border-slate-200 dark:border-slate-800/60 font-mono uppercase">
                Entity: {act.targetType}
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};
