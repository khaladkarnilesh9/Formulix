import React from 'react';
import {
  Search,
  Scale,
  Bookmark,
  Sun,
  Moon,
  Info,
  Menu,
  Database,
} from 'lucide-react';
import { useWorkspaceStore } from '../../stores/workspaceStore';
import { NavItemKey } from './Sidebar';

interface HeaderProps {
  currentTab: NavItemKey;
  onOpenSearch: () => void;
  onNavigate: (tab: NavItemKey) => void;
  onToggleSidebarMobile: () => void;
  onSwitchToAdmin?: () => void;
  breadcrumbSubtitle?: string;
}

export const Header: React.FC<HeaderProps> = ({
  currentTab,
  onOpenSearch,
  onNavigate,
  onToggleSidebarMobile,
  onSwitchToAdmin,
  breadcrumbSubtitle,
}) => {
  const { theme, toggleTheme, setTheme, comparisonProductIds, savedProductIds, savedFormulationIds } = useWorkspaceStore();
  const totalSaved = savedProductIds.length + savedFormulationIds.length;

  const getBreadcrumbTitle = (tab: NavItemKey) => {
    switch (tab) {
      case 'dashboard':
        return 'Executive Formulation Dashboard';
      case 'product-search':
        return 'Commercial Product Intelligence';
      case 'product-detail':
        return 'Product Specification & Dossier';
      case 'formulation-explorer':
        return 'Formulation Recipe Intelligence';
      case 'ingredient-explorer':
        return 'Chemical Substance Explorer';
      case 'product-comparison':
        return 'Multi-Product Formulation Comparison';
      case 'manufacturer-directory':
        return 'Global Manufacturer & Formulator Directory';
      case 'brand-intelligence':
        return 'Brand Portfolio Intelligence';
      case 'regulatory-intelligence':
        return 'Multi-Jurisdiction Regulatory Intelligence';
      case 'patent-intelligence':
        return 'Patent & Prior Art Intelligence';
      case 'technical-documents':
        return 'Technical Dossiers & SDS Archive';
      case 'saved-items':
        return 'Saved Formulations & Products';
      case 'research-workspace':
        return 'Research Notes & Project Workspace';
      case 'settings':
        return 'Platform Settings & Governance';
      default:
        return 'Formulation Intelligence';
    }
  };

  return (
    <header className="sticky top-0 z-30 h-16 bg-white/90 dark:bg-slate-950/90 backdrop-blur-md border-b border-slate-200 dark:border-slate-800 px-4 sm:px-6 flex items-center justify-between gap-4">
      {/* Left: Mobile Menu Toggle & Breadcrumbs */}
      <div className="flex items-center gap-3 min-w-0">
        <button
          onClick={onToggleSidebarMobile}
          className="lg:hidden p-2 rounded-lg text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-900"
          title="Toggle Navigation Menu"
        >
          <Menu className="w-5 h-5" />
        </button>

        <div className="flex flex-col min-w-0">
          <div className="flex items-center gap-1.5 text-xs text-slate-400 font-medium">
            <span>Formulix</span>
            <span>/</span>
            <span className="capitalize">{currentTab.replace('-', ' ')}</span>
          </div>
          <h1 className="text-sm sm:text-base font-semibold text-slate-900 dark:text-white truncate">
            {breadcrumbSubtitle || getBreadcrumbTitle(currentTab)}
          </h1>
        </div>
      </div>

      {/* Center / Right: Global Search Trigger */}
      <div className="flex items-center gap-2 sm:gap-3">
        <button
          onClick={onOpenSearch}
          className="flex items-center gap-2 px-3 py-1.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-900 text-xs text-slate-500 hover:border-slate-300 dark:hover:border-slate-700 hover:text-slate-800 dark:hover:text-slate-200 transition-colors w-40 sm:w-64"
        >
          <Search className="w-3.5 h-3.5 shrink-0" />
          <span className="truncate flex-1 text-left">Search products, CAS...</span>
          <kbd className="hidden sm:inline-block px-1.5 py-0.5 text-[10px] font-mono text-slate-400 bg-white dark:bg-slate-800 rounded border border-slate-200 dark:border-slate-700">
            ⌘K
          </kbd>
        </button>

        {/* Comparison Matrix Quick Button */}
        <button
          onClick={() => onNavigate('product-comparison')}
          className={`relative p-2 rounded-lg border transition-colors ${
            comparisonProductIds.length > 0
              ? 'border-blue-300 dark:border-blue-800 bg-blue-50/50 dark:bg-blue-950/40 text-blue-600 dark:text-blue-400'
              : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-900'
          }`}
          title={`Compare Products (${comparisonProductIds.length} selected)`}
        >
          <Scale className="w-4 h-4" />
          {comparisonProductIds.length > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-blue-600 text-white text-[10px] font-bold flex items-center justify-center">
              {comparisonProductIds.length}
            </span>
          )}
        </button>

        {/* Saved Items Quick Button */}
        <button
          onClick={() => onNavigate('saved-items')}
          className={`relative p-2 rounded-lg border transition-colors ${
            totalSaved > 0
              ? 'border-purple-300 dark:border-purple-800 bg-purple-50/50 dark:bg-purple-950/40 text-purple-600 dark:text-purple-400'
              : 'border-slate-200 dark:border-slate-800 text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-900'
          }`}
          title={`Saved Workspace Items (${totalSaved})`}
        >
          <Bookmark className="w-4 h-4" />
          {totalSaved > 0 && (
            <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-purple-600 text-white text-[10px] font-bold flex items-center justify-center">
              {totalSaved}
            </span>
          )}
        </button>

        {/* Theme Segmented Switcher */}
        <div className="flex items-center p-0.5 rounded-lg border border-slate-200 dark:border-slate-800 bg-slate-100 dark:bg-slate-900 text-xs">
          <button
            onClick={() => setTheme('light')}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md transition-all font-medium ${
              theme === 'light'
                ? 'bg-blue-600 text-white shadow-xs font-semibold'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
            title="Switch to Light Theme"
          >
            <Sun className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Light</span>
          </button>
          <button
            onClick={() => setTheme('dark')}
            className={`flex items-center gap-1.5 px-2.5 py-1 rounded-md transition-all font-medium ${
              theme === 'dark'
                ? 'bg-blue-600 text-white shadow-xs font-semibold'
                : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
            }`}
            title="Switch to Dark Theme"
          >
            <Moon className="w-3.5 h-3.5" />
            <span className="hidden sm:inline">Dark</span>
          </button>
        </div>

        {/* Admin Data Operations Portal Switcher */}
        {onSwitchToAdmin && (
          <button
            onClick={onSwitchToAdmin}
            className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-semibold bg-gradient-to-r from-blue-700 to-indigo-700 hover:from-blue-800 hover:to-indigo-800 text-white shadow-xs transition-all cursor-pointer"
            title="Switch to Enterprise Admin Data Management Portal"
          >
            <Database className="w-3.5 h-3.5 text-blue-200" />
            <span className="hidden sm:inline">Admin Portal</span>
          </button>
        )}

        {/* Enterprise Demonstration Notice */}
        <div className="hidden xl:flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-slate-100 dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-[11px] text-slate-500 font-medium">
          <Info className="w-3.5 h-3.5 text-blue-500 shrink-0" />
          <span>MNC Benchmark Suite · Synthetic Demo</span>
        </div>
      </div>
    </header>
  );
};
