import React from 'react';
import {
  LayoutDashboard,
  Search,
  FlaskConical,
  Atom,
  Scale,
  Building2,
  Tag,
  ShieldCheck,
  FileText,
  Bookmark,
  BookOpen,
  Settings,
  ChevronLeft,
  ChevronRight,
  Database,
  ExternalLink,
} from 'lucide-react';
import { useWorkspaceStore } from '../../stores/workspaceStore';

export type NavItemKey =
  | 'dashboard'
  | 'product-search'
  | 'product-detail'
  | 'formulation-explorer'
  | 'ingredient-explorer'
  | 'product-comparison'
  | 'manufacturer-directory'
  | 'brand-intelligence'
  | 'regulatory-intelligence'
  | 'patent-intelligence'
  | 'technical-documents'
  | 'saved-items'
  | 'research-workspace'
  | 'settings';

interface SidebarProps {
  currentTab: NavItemKey;
  onTabChange: (tab: NavItemKey) => void;
  collapsed: boolean;
  onToggleCollapse: () => void;
  onSwitchToAdmin?: () => void;
}

export const Sidebar: React.FC<SidebarProps> = ({
  currentTab,
  onTabChange,
  collapsed,
  onToggleCollapse,
  onSwitchToAdmin,
}) => {
  const { savedProductIds, savedFormulationIds, comparisonProductIds } = useWorkspaceStore();
  const totalSaved = savedProductIds.length + savedFormulationIds.length;

  const navigationGroups = [
    {
      label: 'Overview',
      items: [
        {
          key: 'dashboard' as NavItemKey,
          label: 'Executive Dashboard',
          icon: LayoutDashboard,
        },
      ],
    },
    {
      label: 'Product Intelligence',
      items: [
        {
          key: 'product-search' as NavItemKey,
          label: 'Product Search',
          icon: Search,
        },
        {
          key: 'formulation-explorer' as NavItemKey,
          label: 'Formulation Explorer',
          icon: FlaskConical,
        },
        {
          key: 'ingredient-explorer' as NavItemKey,
          label: 'Ingredient Explorer',
          icon: Atom,
        },
        {
          key: 'product-comparison' as NavItemKey,
          label: 'Product Comparison',
          icon: Scale,
          badge: comparisonProductIds.length > 0 ? comparisonProductIds.length : undefined,
        },
      ],
    },
    {
      label: 'Market & Companies',
      items: [
        {
          key: 'manufacturer-directory' as NavItemKey,
          label: 'Manufacturer Directory',
          icon: Building2,
        },
        {
          key: 'brand-intelligence' as NavItemKey,
          label: 'Brand Intelligence',
          icon: Tag,
        },
      ],
    },
    {
      label: 'Scientific & Regulatory',
      items: [
        {
          key: 'regulatory-intelligence' as NavItemKey,
          label: 'Regulatory Intelligence',
          icon: ShieldCheck,
        },
        {
          key: 'patent-intelligence' as NavItemKey,
          label: 'Patent Intelligence',
          icon: FileText,
        },
        {
          key: 'technical-documents' as NavItemKey,
          label: 'Technical Documents',
          icon: Database,
        },
      ],
    },
    {
      label: 'Workspace',
      items: [
        {
          key: 'saved-items' as NavItemKey,
          label: 'Saved Items',
          icon: Bookmark,
          badge: totalSaved > 0 ? totalSaved : undefined,
        },
        {
          key: 'research-workspace' as NavItemKey,
          label: 'Research Workspace',
          icon: BookOpen,
        },
      ],
    },
    {
      label: 'System',
      items: [
        {
          key: 'settings' as NavItemKey,
          label: 'Platform Settings',
          icon: Settings,
        },
      ],
    },
  ];

  return (
    <aside
      className={`fixed left-0 top-0 bottom-0 z-40 bg-white dark:bg-slate-950 border-r border-slate-200 dark:border-slate-800 transition-all duration-300 flex flex-col ${
        collapsed ? 'w-18' : 'w-64'
      }`}
    >
      {/* Brand Header */}
      <div className="h-16 flex items-center justify-between px-4 border-b border-slate-200 dark:border-slate-800">
        {!collapsed ? (
          <div className="flex items-center gap-2.5 overflow-hidden">
            <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold text-sm shadow-xs shrink-0">
              Fx
            </div>
            <div className="flex flex-col min-w-0">
              <span className="text-base font-bold tracking-tight text-slate-900 dark:text-white truncate">
                Formulix
              </span>
              <span className="text-[10px] tracking-wide text-slate-400 font-mono truncate uppercase">
                Product Intelligence
              </span>
            </div>
          </div>
        ) : (
          <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center text-white font-bold text-sm mx-auto shadow-xs">
            Fx
          </div>
        )}

        <button
          onClick={onToggleCollapse}
          className={`p-1.5 rounded-lg text-slate-400 hover:text-slate-600 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-900 transition-colors ${
            collapsed ? 'hidden sm:block mx-auto mt-2' : ''
          }`}
          title={collapsed ? 'Expand Sidebar' : 'Collapse Sidebar'}
        >
          {collapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
        </button>
      </div>

      {/* Navigation Scroll Area */}
      <div className="flex-1 overflow-y-auto py-3 px-2 space-y-4">
        {navigationGroups.map((group) => (
          <div key={group.label} className="space-y-0.5">
            {!collapsed && (
              <div className="px-3 py-1 text-[11px] font-semibold tracking-wider text-slate-400 uppercase">
                {group.label}
              </div>
            )}
            {group.items.map((item) => {
              const Icon = item.icon;
              const isActive =
                currentTab === item.key ||
                (item.key === 'product-search' && currentTab === 'product-detail');

              return (
                <button
                  key={item.key}
                  onClick={() => onTabChange(item.key)}
                  title={collapsed ? item.label : undefined}
                  className={`w-full flex items-center gap-3 px-3 py-2 rounded-lg text-xs font-medium transition-colors text-left relative ${
                    isActive
                      ? 'bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-400 font-semibold'
                      : 'text-slate-600 dark:text-slate-400 hover:bg-slate-100 dark:hover:bg-slate-900/80 hover:text-slate-900 dark:hover:text-slate-200'
                  }`}
                >
                  <Icon
                    className={`w-4 h-4 shrink-0 ${
                      isActive ? 'text-blue-600 dark:text-blue-400' : 'text-slate-400'
                    }`}
                  />
                  {!collapsed && (
                    <span className="truncate flex-1">{item.label}</span>
                  )}
                  {item.badge !== undefined && (
                    <span
                      className={`text-[10px] font-mono px-1.5 py-0.2 rounded-full font-semibold ${
                        isActive
                          ? 'bg-blue-600 text-white'
                          : 'bg-slate-200 text-slate-700 dark:bg-slate-800 dark:text-slate-300'
                      } ${collapsed ? 'absolute top-1.5 right-1.5' : ''}`}
                    >
                      {item.badge}
                    </span>
                  )}
                </button>
              );
            })}
          </div>
        ))}
      </div>

      {/* Admin Switcher Shortcut */}
      {onSwitchToAdmin && (
        <div className="p-2 border-t border-slate-200 dark:border-slate-800">
          <button
            onClick={onSwitchToAdmin}
            title={collapsed ? "Admin Data Operations Portal" : undefined}
            className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-lg text-xs font-semibold bg-gradient-to-r from-blue-600/10 to-indigo-600/10 hover:from-blue-600/20 hover:to-indigo-600/20 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-800/80 transition-colors ${
              collapsed ? 'justify-center' : ''
            }`}
          >
            <Database className="w-4 h-4 shrink-0 text-blue-600 dark:text-blue-400" />
            {!collapsed && (
              <div className="flex-1 text-left">
                <span className="block leading-tight">Admin Data Ops</span>
                <span className="text-[10px] text-slate-400 font-normal">Full Schema Access</span>
              </div>
            )}
          </button>
        </div>
      )}

      {/* Footer System Status */}
      {!collapsed ? (
        <div className="p-3 border-t border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50 text-[11px]">
          <div className="flex items-center justify-between text-slate-500 mb-1">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-500" />
              Intelligence Index Active
            </span>
            <span className="font-mono text-[10px]">v2.6</span>
          </div>
          <p className="text-[10px] text-slate-400 leading-tight">
            Synthetic chemical & formulation research models for enterprise analysis.
          </p>
        </div>
      ) : (
        <div className="p-2 border-t border-slate-200 dark:border-slate-800 text-center">
          <span className="w-2 h-2 rounded-full bg-emerald-500 inline-block" title="System Online" />
        </div>
      )}
    </aside>
  );
};
