import React from 'react';
import { VerificationEvidence, RegistrationStatus } from '../../types';
import { ShieldCheck, FileCheck, BookOpen, AlertCircle, Sparkles } from 'lucide-react';

interface EvidenceBadgeProps {
  evidence: VerificationEvidence;
  size?: 'sm' | 'md';
}

export const EvidenceBadge: React.FC<EvidenceBadgeProps> = ({ evidence, size = 'sm' }) => {
  const isSmall = size === 'sm';

  switch (evidence) {
    case 'Regulatory verified':
      return (
        <span
          className={`inline-flex items-center gap-1.5 font-medium text-emerald-700 dark:text-emerald-400 ${
            isSmall ? 'text-xs' : 'text-sm'
          }`}
          title="Verified against official regulatory gazette or authority register"
        >
          <ShieldCheck className={isSmall ? 'w-3.5 h-3.5' : 'w-4 h-4'} />
          <span>Regulatory Verified</span>
        </span>
      );

    case 'Manufacturer disclosed':
      return (
        <span
          className={`inline-flex items-center gap-1.5 font-medium text-blue-700 dark:text-blue-400 ${
            isSmall ? 'text-xs' : 'text-sm'
          }`}
          title="Disclosed in manufacturer technical bulletin or commercial TDS"
        >
          <FileCheck className={isSmall ? 'w-3.5 h-3.5' : 'w-4 h-4'} />
          <span>Manufacturer Disclosed</span>
        </span>
      );

    case 'Patent disclosed':
      return (
        <span
          className={`inline-flex items-center gap-1.5 font-medium text-purple-700 dark:text-purple-400 ${
            isSmall ? 'text-xs' : 'text-sm'
          }`}
          title="Extracted from published patent specifications and claims"
        >
          <BookOpen className={isSmall ? 'w-3.5 h-3.5' : 'w-4 h-4'} />
          <span>Patent Disclosed</span>
        </span>
      );

    case 'Literature reported':
      return (
        <span
          className={`inline-flex items-center gap-1.5 font-medium text-amber-700 dark:text-amber-400 ${
            isSmall ? 'text-xs' : 'text-sm'
          }`}
          title="Peer-reviewed literature or academic formulation study"
        >
          <BookOpen className={isSmall ? 'w-3.5 h-3.5' : 'w-4 h-4'} />
          <span>Literature Reported</span>
        </span>
      );

    case 'Synthetic demo data':
    default:
      return (
        <span
          className={`inline-flex items-center gap-1.5 font-medium text-slate-500 dark:text-slate-400 ${
            isSmall ? 'text-xs' : 'text-sm'
          }`}
          title="Synthetic model data provided for demonstration purposes"
        >
          <Sparkles className={isSmall ? 'w-3.5 h-3.5' : 'w-4 h-4'} />
          <span>Demo Synthetic Model</span>
        </span>
      );
  }
};

interface StatusIndicatorProps {
  status: RegistrationStatus;
}

export const StatusIndicator: React.FC<StatusIndicatorProps> = ({ status }) => {
  let dotColor = 'bg-slate-400';
  let textColor = 'text-slate-600 dark:text-slate-300';

  if (status === 'Approved' || status === 'Active') {
    dotColor = 'bg-emerald-500';
    textColor = 'text-emerald-700 dark:text-emerald-400';
  } else if (status === 'Under Review' || status === 'Conditional') {
    dotColor = 'bg-amber-500';
    textColor = 'text-amber-700 dark:text-amber-400';
  } else if (status === 'Withdrawn') {
    dotColor = 'bg-rose-500';
    textColor = 'text-rose-700 dark:text-rose-400';
  }

  return (
    <span className={`inline-flex items-center gap-1.5 text-xs font-medium ${textColor}`}>
      <span className={`w-1.5 h-1.5 rounded-full ${dotColor}`} />
      <span>{status}</span>
    </span>
  );
};
