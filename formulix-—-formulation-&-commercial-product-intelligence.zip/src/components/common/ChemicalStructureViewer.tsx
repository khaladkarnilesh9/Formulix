import React, { useState } from 'react';
import { ZoomIn, ZoomOut, RotateCcw, Copy, Check } from 'lucide-react';

interface ChemicalStructureViewerProps {
  smiles?: string;
  name: string;
  formula: string;
  weight: number;
  structureType?: 'heterocycle' | 'aromatic' | 'chain' | 'polymeric' | 'complex';
}

export const ChemicalStructureViewer: React.FC<ChemicalStructureViewerProps> = ({
  smiles,
  name,
  formula,
  weight,
  structureType = 'aromatic',
}) => {
  const [zoom, setZoom] = useState(1);
  const [copied, setCopied] = useState(false);

  const handleCopySmiles = () => {
    if (!smiles) return;
    navigator.clipboard.writeText(smiles);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleResetZoom = () => setZoom(1);
  const handleZoomIn = () => setZoom((z) => Math.min(z + 0.25, 2.0));
  const handleZoomOut = () => setZoom((z) => Math.max(z - 0.25, 0.6));

  // Render authentic 2D skeletal formulas for the various chemical classes
  const renderStructureSvg = () => {
    switch (structureType) {
      case 'heterocycle':
        // Imidacloprid / Thiamethoxam style imidazolidine / thiazole + pyridine
        return (
          <g transform={`scale(${zoom})`} transform-origin="150 100" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
            {/* Pyridine ring */}
            <polygon points="50,90 75,75 100,90 100,120 75,135 50,120" fill="none" className="stroke-slate-700 dark:stroke-slate-200" />
            <line x1="75" y1="80" x2="95" y2="92" className="stroke-slate-700 dark:stroke-slate-200" />
            <line x1="95" y1="117" x2="75" y2="129" className="stroke-slate-700 dark:stroke-slate-200" />
            {/* N in pyridine */}
            <circle cx="50" cy="105" r="7" className="fill-slate-50 dark:fill-slate-900" />
            <text x="47" y="109" className="fill-blue-600 dark:fill-blue-400 font-sans font-bold text-[11px]">N</text>
            {/* Chloro substituent */}
            <line x1="100" y1="120" x2="122" y2="132" className="stroke-slate-700 dark:stroke-slate-200" />
            <text x="123" y="138" className="fill-emerald-600 dark:fill-emerald-400 font-sans font-bold text-[12px]">Cl</text>
            {/* Methylene bridge to imidazolidine */}
            <line x1="75" y1="75" x2="90" y2="48" className="stroke-slate-700 dark:stroke-slate-200" />
            <line x1="90" y1="48" x2="118" y2="48" className="stroke-slate-700 dark:stroke-slate-200" />
            {/* Imidazolidine ring */}
            <polygon points="135,48 165,35 185,60 170,90 135,80" fill="none" className="stroke-slate-700 dark:stroke-slate-200" />
            {/* N1 */}
            <circle cx="135" cy="48" r="7" className="fill-slate-50 dark:fill-slate-900" />
            <text x="131" y="52" className="fill-blue-600 dark:fill-blue-400 font-sans font-bold text-[11px]">N</text>
            {/* N3 */}
            <circle cx="170" cy="90" r="7" className="fill-slate-50 dark:fill-slate-900" />
            <text x="166" y="94" className="fill-blue-600 dark:fill-blue-400 font-sans font-bold text-[11px]">N</text>
            {/* Exocyclic C=N-NO2 group */}
            <line x1="135" y1="80" x2="120" y2="110" className="stroke-slate-700 dark:stroke-slate-200" />
            <line x1="138" y1="83" x2="123" y2="113" className="stroke-slate-700 dark:stroke-slate-200" />
            <circle cx="120" cy="115" r="7" className="fill-slate-50 dark:fill-slate-900" />
            <text x="116" y="119" className="fill-blue-600 dark:fill-blue-400 font-sans font-bold text-[11px]">N</text>
            {/* NO2 */}
            <line x1="120" y1="122" x2="120" y2="148" className="stroke-slate-700 dark:stroke-slate-200" />
            <circle cx="120" cy="155" r="7" className="fill-slate-50 dark:fill-slate-900" />
            <text x="116" y="159" className="fill-blue-600 dark:fill-blue-400 font-sans font-bold text-[11px]">N⁺</text>
            <line x1="114" y1="160" x2="95" y2="172" className="stroke-slate-700 dark:stroke-slate-200" />
            <text x="85" y="177" className="fill-rose-600 dark:fill-rose-400 font-sans font-bold text-[12px]">O⁻</text>
            <line x1="126" y1="160" x2="145" y2="172" className="stroke-slate-700 dark:stroke-slate-200" />
            <line x1="129" y1="156" x2="148" y2="168" className="stroke-slate-700 dark:stroke-slate-200" />
            <text x="148" y="177" className="fill-rose-600 dark:fill-rose-400 font-sans font-bold text-[12px]">O</text>
          </g>
        );

      case 'aromatic':
        // Paracetamol / Azoxystrobin / Ibuprofen phenolic or aromatic motif
        return (
          <g transform={`scale(${zoom})`} transform-origin="150 100" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
            {/* Central Benzene Ring */}
            <polygon points="120,70 150,52 180,70 180,105 150,123 120,105" fill="none" className="stroke-slate-700 dark:stroke-slate-200" />
            {/* Double bonds */}
            <line x1="148" y1="58" x2="174" y2="73" className="stroke-slate-700 dark:stroke-slate-200" />
            <line x1="174" y1="102" x2="150" y2="116" className="stroke-slate-700 dark:stroke-slate-200" />
            <line x1="126" y1="102" x2="126" y2="73" className="stroke-slate-700 dark:stroke-slate-200" />
            {/* Hydroxyl group */}
            <line x1="120" y1="70" x2="90" y2="52" className="stroke-slate-700 dark:stroke-slate-200" />
            <text x="70" y="52" className="fill-rose-600 dark:fill-rose-400 font-sans font-bold text-[12px]">HO</text>
            {/* Amide group (Acetamide / ester chain) */}
            <line x1="180" y1="105" x2="208" y2="122" className="stroke-slate-700 dark:stroke-slate-200" />
            <circle cx="210" cy="123" r="7" className="fill-slate-50 dark:fill-slate-900" />
            <text x="206" y="127" className="fill-blue-600 dark:fill-blue-400 font-sans font-bold text-[11px]">NH</text>
            <line x1="222" y1="122" x2="245" y2="108" className="stroke-slate-700 dark:stroke-slate-200" />
            {/* Carbonyl C=O */}
            <line x1="243" y1="108" x2="243" y2="82" className="stroke-slate-700 dark:stroke-slate-200" />
            <line x1="247" y1="108" x2="247" y2="82" className="stroke-slate-700 dark:stroke-slate-200" />
            <text x="240" y="78" className="fill-rose-600 dark:fill-rose-400 font-sans font-bold text-[12px]">O</text>
            {/* Methyl tail */}
            <line x1="245" y1="108" x2="272" y2="124" className="stroke-slate-700 dark:stroke-slate-200" />
          </g>
        );

      case 'chain':
        // SLS / Metformin / Acetone / Ethyl Acetate aliphatic backbone
        return (
          <g transform={`scale(${zoom})`} transform-origin="150 100" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
            <polyline
              points="40,110 65,95 90,110 115,95 140,110 165,95 190,110 215,95 240,110"
              fill="none"
              className="stroke-slate-700 dark:stroke-slate-200"
            />
            {/* Sulfate or ester end group */}
            <line x1="240" y1="110" x2="260" y2="98" className="stroke-slate-700 dark:stroke-slate-200" />
            <text x="262" y="98" className="fill-rose-600 dark:fill-rose-400 font-sans font-bold text-[12px]">O</text>
            <line x1="274" y1="94" x2="290" y2="94" className="stroke-slate-700 dark:stroke-slate-200" />
            <text x="292" y="98" className="fill-amber-500 font-sans font-bold text-[12px]">SO₃⁻</text>
            <text x="318" y="98" className="fill-blue-600 dark:fill-blue-400 font-sans font-bold text-[12px]">Na⁺</text>
          </g>
        );

      case 'polymeric':
        // PEG-400 polyether repeat units
        return (
          <g transform={`scale(${zoom})`} transform-origin="150 100" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
            <text x="40" y="105" className="fill-rose-600 dark:fill-rose-400 font-sans font-bold text-[12px]">HO</text>
            <line x1="62" y1="102" x2="85" y2="88" className="stroke-slate-700 dark:stroke-slate-200" />
            <line x1="85" y1="88" x2="110" y2="102" className="stroke-slate-700 dark:stroke-slate-200" />
            <circle cx="110" cy="102" r="6" className="fill-slate-50 dark:fill-slate-900" />
            <text x="106" y="106" className="fill-rose-600 dark:fill-rose-400 font-sans font-bold text-[11px]">O</text>
            {/* Brackets for repeat unit */}
            <line x1="120" y1="75" x2="120" y2="125" strokeDasharray="3 3" className="stroke-slate-400" />
            <line x1="120" y1="102" x2="140" y2="88" className="stroke-slate-700 dark:stroke-slate-200" />
            <line x1="140" y1="88" x2="165" y2="102" className="stroke-slate-700 dark:stroke-slate-200" />
            <circle cx="165" cy="102" r="6" className="fill-slate-50 dark:fill-slate-900" />
            <text x="161" y="106" className="fill-rose-600 dark:fill-rose-400 font-sans font-bold text-[11px]">O</text>
            <line x1="172" y1="102" x2="195" y2="88" className="stroke-slate-700 dark:stroke-slate-200" />
            <line x1="195" y1="88" x2="215" y2="102" className="stroke-slate-700 dark:stroke-slate-200" />
            <line x1="220" y1="75" x2="220" y2="125" strokeDasharray="3 3" className="stroke-slate-400" />
            <text x="224" y="128" className="fill-slate-500 font-mono text-[11px]">n≈8-9</text>
            <line x1="225" y1="102" x2="245" y2="102" className="stroke-slate-700 dark:stroke-slate-200" />
            <text x="248" y="105" className="fill-rose-600 dark:fill-rose-400 font-sans font-bold text-[12px]">OH</text>
          </g>
        );

      case 'complex':
      default:
        // Chlorantraniliprole / Amoxicillin condensed polycyclic system
        return (
          <g transform={`scale(${zoom})`} transform-origin="150 100" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round">
            {/* Pyrazole ring */}
            <polygon points="120,100 138,80 162,90 158,115 132,122" fill="none" className="stroke-slate-700 dark:stroke-slate-200" />
            {/* N in pyrazole */}
            <circle cx="138" cy="80" r="6" className="fill-slate-50 dark:fill-slate-900" />
            <text x="135" y="84" className="fill-blue-600 dark:fill-blue-400 font-sans font-bold text-[11px]">N</text>
            <circle cx="162" cy="90" r="6" className="fill-slate-50 dark:fill-slate-900" />
            <text x="158" y="94" className="fill-blue-600 dark:fill-blue-400 font-sans font-bold text-[11px]">N</text>
            {/* Pyridine branch */}
            <line x1="162" y1="90" x2="190" y2="82" className="stroke-slate-700 dark:stroke-slate-200" />
            <polygon points="190,82 212,68 234,82 234,108 212,122 190,108" fill="none" className="stroke-slate-700 dark:stroke-slate-200" />
            <circle cx="234" cy="95" r="6" className="fill-slate-50 dark:fill-slate-900" />
            <text x="231" y="99" className="fill-blue-600 dark:fill-blue-400 font-sans font-bold text-[10px]">N</text>
            {/* Cl on pyridine */}
            <line x1="234" y1="108" x2="250" y2="120" className="stroke-slate-700 dark:stroke-slate-200" />
            <text x="252" y="126" className="fill-emerald-600 dark:fill-emerald-400 font-sans font-bold text-[12px]">Cl</text>
            {/* Bromo substituent on pyrazole */}
            <line x1="120" y1="100" x2="98" y2="92" className="stroke-slate-700 dark:stroke-slate-200" />
            <text x="82" y="96" className="fill-red-700 dark:fill-red-400 font-sans font-bold text-[12px]">Br</text>
            {/* Anthranilic carboxamide core */}
            <line x1="132" y1="122" x2="132" y2="148" className="stroke-slate-700 dark:stroke-slate-200" />
            <line x1="130" y1="148" x2="112" y2="160" className="stroke-slate-700 dark:stroke-slate-200" />
            <text x="100" y="166" className="fill-rose-600 dark:fill-rose-400 font-sans font-bold text-[12px]">O</text>
            <line x1="132" y1="148" x2="152" y2="160" className="stroke-slate-700 dark:stroke-slate-200" />
            <text x="154" y="166" className="fill-blue-600 dark:fill-blue-400 font-sans font-bold text-[11px]">NH</text>
          </g>
        );
    }
  };

  return (
    <div className="flex flex-col bg-slate-50 dark:bg-slate-900/60 border border-slate-200 dark:border-slate-800 rounded-lg overflow-hidden">
      {/* Top action bar */}
      <div className="flex items-center justify-between px-3 py-2 border-b border-slate-200 dark:border-slate-800 bg-white dark:bg-slate-900 text-xs text-slate-600 dark:text-slate-400">
        <div className="flex items-center gap-2">
          <span className="font-semibold text-slate-800 dark:text-slate-200">{name}</span>
          <span className="font-mono text-slate-500">[{formula}]</span>
        </div>
        <div className="flex items-center gap-1">
          <button
            onClick={handleZoomIn}
            className="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded text-slate-600 dark:text-slate-300"
            title="Zoom In"
          >
            <ZoomIn className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={handleZoomOut}
            className="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded text-slate-600 dark:text-slate-300"
            title="Zoom Out"
          >
            <ZoomOut className="w-3.5 h-3.5" />
          </button>
          <button
            onClick={handleResetZoom}
            className="p-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded text-slate-600 dark:text-slate-300"
            title="Reset Zoom"
          >
            <RotateCcw className="w-3.5 h-3.5" />
          </button>
          {smiles && (
            <button
              onClick={handleCopySmiles}
              className="flex items-center gap-1 px-2 py-1 hover:bg-slate-100 dark:hover:bg-slate-800 rounded text-slate-600 dark:text-slate-300"
              title="Copy SMILES Notation"
            >
              {copied ? <Check className="w-3.5 h-3.5 text-emerald-500" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copied ? 'Copied' : 'SMILES'}</span>
            </button>
          )}
        </div>
      </div>

      {/* SVG Canvas Area */}
      <div className="relative w-full h-56 flex items-center justify-center p-4 overflow-hidden select-none">
        <svg
          viewBox="0 0 320 200"
          className="w-full h-full max-h-52 drop-shadow-sm transition-transform duration-150"
        >
          {renderStructureSvg()}
        </svg>

        {/* Molecular Weight Legend */}
        <div className="absolute bottom-2 left-3 text-[11px] font-mono text-slate-500 dark:text-slate-400">
          MW: <span className="text-slate-800 dark:text-slate-200 font-semibold">{weight.toFixed(2)} g/mol</span>
        </div>

        {/* Renderer label for enterprise readiness */}
        <div className="absolute bottom-2 right-3 text-[10px] text-slate-400 dark:text-slate-500 uppercase tracking-wider font-mono">
          2D Skeletal Projection · RDKit Ready
        </div>
      </div>
    </div>
  );
};
