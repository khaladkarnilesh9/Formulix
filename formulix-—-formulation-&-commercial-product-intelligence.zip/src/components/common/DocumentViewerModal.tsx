import React from 'react';
import { TechnicalDocument } from '../../types';
import { X, Download, ExternalLink, FileText, Calendar, Building, CheckCircle, ShieldAlert } from 'lucide-react';
import { useToast } from './Toast';

interface DocumentViewerModalProps {
  document: TechnicalDocument | null;
  onClose: () => void;
  onSelectProduct?: (productName: string) => void;
  onSelectIngredient?: (ingredientName: string) => void;
}

export const DocumentViewerModal: React.FC<DocumentViewerModalProps> = ({
  document,
  onClose,
  onSelectProduct,
  onSelectIngredient,
}) => {
  const { toast } = useToast();

  if (!document) return null;

  const handleDownload = () => {
    // Generate synthetic file download simulation
    const content = `FORMULIX SCIENTIFIC DOSSIER ARCHIVE\n===================================\nDocument ID: ${document.documentNumber}\nTitle: ${document.title}\nIssuer: ${document.issuer}\nDate: ${document.publicationDate}\nStatus: ${document.verifiedStatus}\n\nEXECUTIVE SUMMARY:\n${document.summary}\n\nRELATED PRODUCTS:\n${document.relatedProducts.join(', ')}\n\nRELATED INGREDIENTS:\n${document.relatedIngredients.join(', ')}\n\nSOURCE REFERENCE:\n${document.sourceUrl}\n\nDisclaimer: This is synthetic demonstration data extracted for Formulix platform testing.\n`;
    const blob = new Blob([content], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = window.document.createElement('a');
    a.href = url;
    a.download = `${document.documentNumber.replace(/[^a-zA-Z0-9_-]/g, '_')}_summary.txt`;
    a.click();
    URL.revokeObjectURL(url);
    toast(`Downloaded document archive: ${document.documentNumber}`);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-950/70 backdrop-blur-xs animate-in fade-in">
      <div className="relative w-full max-w-3xl bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Modal Header */}
        <div className="flex items-start justify-between p-5 border-b border-slate-200 dark:border-slate-800 bg-slate-50/50 dark:bg-slate-950/50">
          <div className="space-y-1 pr-6">
            <div className="flex items-center gap-2 text-xs font-mono text-blue-600 dark:text-blue-400">
              <span className="font-semibold">{document.type}</span>
              <span>·</span>
              <span>{document.documentNumber}</span>
            </div>
            <h2 className="text-lg font-semibold text-slate-900 dark:text-white leading-snug">
              {document.title}
            </h2>
          </div>
          <button
            onClick={onClose}
            className="p-1.5 rounded-lg text-slate-400 hover:text-slate-700 dark:hover:text-slate-200 hover:bg-slate-100 dark:hover:bg-slate-800 transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Modal Body */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Metadata Grid */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-lg bg-slate-50 dark:bg-slate-950/50 border border-slate-200 dark:border-slate-800/80 text-xs">
            <div>
              <div className="text-slate-500 mb-0.5">Issuing Authority</div>
              <div className="font-medium text-slate-900 dark:text-slate-100 flex items-center gap-1">
                <Building className="w-3.5 h-3.5 text-slate-400" />
                {document.issuer}
              </div>
            </div>
            <div>
              <div className="text-slate-500 mb-0.5">Publication Date</div>
              <div className="font-medium text-slate-900 dark:text-slate-100 flex items-center gap-1 font-mono">
                <Calendar className="w-3.5 h-3.5 text-slate-400" />
                {document.publicationDate}
              </div>
            </div>
            <div>
              <div className="text-slate-500 mb-0.5">Format & Size</div>
              <div className="font-medium text-slate-900 dark:text-slate-100 font-mono">
                {document.format} ({document.fileSize})
              </div>
            </div>
            <div>
              <div className="text-slate-500 mb-0.5">Verification</div>
              <div className="font-medium text-emerald-600 dark:text-emerald-400 flex items-center gap-1">
                <CheckCircle className="w-3.5 h-3.5" />
                {document.verifiedStatus}
              </div>
            </div>
          </div>

          {/* Document Summary / Abstract */}
          <div>
            <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2">
              Document Abstract & Executive Summary
            </h3>
            <div className="p-4 rounded-lg bg-white dark:bg-slate-900 border border-slate-200 dark:border-slate-800 text-sm leading-relaxed text-slate-700 dark:text-slate-300">
              {document.summary}
            </div>
          </div>

          {/* Related Entities */}
          <div className="grid sm:grid-cols-2 gap-4">
            <div className="p-4 rounded-lg border border-slate-200 dark:border-slate-800">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2.5">
                Related Commercial Products
              </h4>
              <div className="flex flex-wrap gap-2">
                {document.relatedProducts.map((prod) => (
                  <button
                    key={prod}
                    onClick={() => {
                      onClose();
                      onSelectProduct?.(prod);
                    }}
                    className="text-xs px-2.5 py-1 rounded-md bg-blue-50 text-blue-700 dark:bg-blue-950/60 dark:text-blue-300 hover:bg-blue-100 dark:hover:bg-blue-900 transition-colors font-medium text-left"
                  >
                    {prod}
                  </button>
                ))}
              </div>
            </div>

            <div className="p-4 rounded-lg border border-slate-200 dark:border-slate-800">
              <h4 className="text-xs font-semibold uppercase tracking-wider text-slate-500 mb-2.5">
                Active Chemical Substances
              </h4>
              <div className="flex flex-wrap gap-2">
                {document.relatedIngredients.map((ing) => (
                  <button
                    key={ing}
                    onClick={() => {
                      onClose();
                      onSelectIngredient?.(ing);
                    }}
                    className="text-xs px-2.5 py-1 rounded-md bg-purple-50 text-purple-700 dark:bg-purple-950/60 dark:text-purple-300 hover:bg-purple-100 dark:hover:bg-purple-900 transition-colors font-medium text-left"
                  >
                    {ing}
                  </button>
                ))}
              </div>
            </div>
          </div>

          {/* Regulatory & Licensing Disclaimer */}
          <div className="flex items-start gap-3 p-3.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-xs text-amber-800 dark:text-amber-300">
            <ShieldAlert className="w-4 h-4 shrink-0 mt-0.5" />
            <div className="leading-relaxed">
              <span className="font-semibold">Notice & Source Compliance: </span>
              This record indexes public regulatory filings, patent registries, or open technical literature for formulation intelligence research. Formulix does not host proprietary third-party commercial trade secrets.
            </div>
          </div>
        </div>

        {/* Modal Footer */}
        <div className="flex items-center justify-between p-4 border-t border-slate-200 dark:border-slate-800 bg-slate-50 dark:bg-slate-950">
          <a
            href={document.sourceUrl}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-1.5 text-xs font-medium text-blue-600 dark:text-blue-400 hover:underline"
          >
            <span>Access Official Publication Portal</span>
            <ExternalLink className="w-3.5 h-3.5" />
          </a>
          <div className="flex items-center gap-2">
            <button
              onClick={onClose}
              className="px-4 py-2 text-xs font-medium text-slate-700 dark:text-slate-300 hover:bg-slate-200 dark:hover:bg-slate-800 rounded-lg transition-colors"
            >
              Close
            </button>
            <button
              onClick={handleDownload}
              className="inline-flex items-center gap-1.5 px-4 py-2 text-xs font-medium text-white bg-blue-600 hover:bg-blue-700 rounded-lg shadow-sm transition-colors"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Download Record Summary</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};
